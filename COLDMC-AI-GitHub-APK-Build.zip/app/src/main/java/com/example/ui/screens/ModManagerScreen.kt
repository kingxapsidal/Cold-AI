package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ModrinthHit
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModManagerScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    var selectedLoader by remember { mutableStateOf("fabric") }
    var searchQuery by remember { mutableStateOf("Lithium") }
    val hits by viewModel.modrinthModHits.collectAsState()
    val isSearching by viewModel.isSearchingMods.collectAsState()
    val currentFiles by viewModel.currentFiles.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.searchMods("Lithium", "fabric")
        viewModel.navigateToDirectory("/mods")
    }

    val installedMods = currentFiles.filter { it.name.endsWith(".jar") }

    val popularMods = listOf("Lithium", "FerriteCore", "ModernFix", "Krypton", "Spark", "Fabric API", "Cloth Config")

    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Minecraft Mod Manager", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Fabric • Forge • NeoForge Ecosystem", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = IceCyan
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Mod Catalogue", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        viewModel.navigateToDirectory("/mods")
                    },
                    text = { Text("Installed (${installedMods.size})", fontWeight = FontWeight.Bold) }
                )
            }

            if (selectedTab == 0) {
                Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    // Loader filter chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("fabric" to "Fabric", "forge" to "Forge", "neoforge" to "NeoForge").forEach { (loaderKey, loaderLabel) ->
                            FilterChip(
                                selected = selectedLoader == loaderKey,
                                onClick = {
                                    selectedLoader = loaderKey
                                    viewModel.searchMods(searchQuery, loaderKey)
                                },
                                label = { Text(loaderLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IceCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Search input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search Modrinth mods...") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mod_search_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IceCyan,
                                unfocusedBorderColor = CyberBorder
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.searchMods(searchQuery, selectedLoader) },
                            colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                            modifier = Modifier.height(54.dp).testTag("mod_search_button")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        popularMods.take(4).forEach { name ->
                            SuggestionChip(
                                onClick = {
                                    searchQuery = name
                                    viewModel.searchMods(name, selectedLoader)
                                },
                                label = { Text(name, fontSize = 11.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = DarkCard,
                                    labelColor = IceCyan
                                ),
                                border = SuggestionChipDefaults.suggestionChipBorder(
                                    borderColor = CyberBorder,
                                    enabled = true
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (isSearching) {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = IceCyan)
                        }
                    } else if (hits.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text("No mods found matching '$searchQuery' for $selectedLoader", color = TextSecondary)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(hits, key = { it.projectId }) { hit ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(hit.title, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                                                Text("Slug: ${hit.slug} • Downloads: ${hit.downloads}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                            }
                                            Badge(containerColor = DarkCard, contentColor = IceCyan) {
                                                Text(selectedLoader.uppercase(), fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(hit.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 2)

                                        Spacer(modifier = Modifier.height(10.dp))
                                        Button(
                                            onClick = { viewModel.installMod(hit) },
                                            colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("install_mod_${hit.slug}")
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Download & Install to /mods", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Installed Mods Tab
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("Installed Mods in /mods/", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    if (installedMods.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                Text("No .jar mod files detected in /mods directory.", color = TextMuted)
                            }
                        }
                    } else {
                        items(installedMods) { modFile ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CyberBorder, RoundedCornerShape(10.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(modFile.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        Text("${modFile.size / 1024} KB", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    }
                                    IconButton(onClick = { viewModel.deleteFile(modFile.name) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = OfflineRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
