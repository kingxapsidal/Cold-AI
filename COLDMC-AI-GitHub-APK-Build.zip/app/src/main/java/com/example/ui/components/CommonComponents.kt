package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColdMcTopBar(
    title: String,
    subtitle: String? = null,
    serverState: String = "offline",
    onConnectionClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onMenuNavigate: (String) -> Unit = {}
) {

    Surface(
        color = DarkSurface,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onConnectionClick() }
                    .padding(vertical = 4.dp, horizontal = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(IceCyan, DeepCyan)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Dns,
                        contentDescription = "Server Icon",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        StatusIndicatorDot(serverState)
                    }
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                var menuExpanded by remember { mutableStateOf(false) }

                IconButton(
                    onClick = onRefreshClick,
                    modifier = Modifier.testTag("refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Telemetry",
                        tint = IceCyan
                    )
                }

                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.testTag("hub_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = "Feature Hub Menu",
                        tint = IceCyan
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(DarkSurface)
                ) {
                    DropdownMenuItem(
                        text = { Text("Multiple Panels", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.CloudQueue, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("panels") }
                    )
                    DropdownMenuItem(
                        text = { Text("Multiple Servers", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("servers") }
                    )
                    DropdownMenuItem(
                        text = { Text("Performance & TPS", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Speed, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("performance") }
                    )
                    DropdownMenuItem(
                        text = { Text("Mod Manager", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("mods") }
                    )
                    DropdownMenuItem(
                        text = { Text("Crash Doctor", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.BugReport, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("crash_analysis") }
                    )
                    DropdownMenuItem(
                        text = { Text("Discord Bot & Alerts", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("discord") }
                    )
                    DropdownMenuItem(
                        text = { Text("Activity History / Audit", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("activity_history") }
                    )
                    DropdownMenuItem(
                        text = { Text("Backups", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Backup, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("backups") }
                    )
                    DropdownMenuItem(
                        text = { Text("File Manager", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("files") }
                    )
                    DropdownMenuItem(
                        text = { Text("Wi-Fi Gateway & Settings", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("settings") }
                    )
                    DropdownMenuItem(
                        text = { Text("Welcome & Splash", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, tint = IceCyan) },
                        onClick = { menuExpanded = false; onMenuNavigate("welcome") }
                    )
                }
            }
        }
    }
}


@Composable
fun StatusIndicatorDot(state: String) {
    val color = when (state.lowercase()) {
        "running" -> OnlineGreen
        "starting" -> StartingAmber
        "stopping" -> StoppingOrange
        else -> OfflineRed
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = if (state.lowercase() == "running" || state.lowercase() == "starting") alpha else 1f))
            .border(1.dp, color, CircleShape)
    )
}

@Composable
fun MetricCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    subValue: String? = null,
    progress: Float? = null,
    progressColor: Color = IceCyan,
    icon: ImageVector
) {
    Card(
        modifier = modifier
            .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(progressColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = progressColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            if (subValue != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subValue,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }

            if (progress != null) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = progressColor,
                    trackColor = DarkSurfaceElevated
                )
            }
        }
    }
}

@Composable
fun ConfirmationDialog(
    title: String,
    message: String,
    confirmText: String = "Confirm",
    cancelText: String = "Cancel",
    isDestructive: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isDestructive) Icons.Default.Warning else Icons.Default.Info,
                    contentDescription = null,
                    tint = if (isDestructive) OfflineRed else IceCyan
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Text(text = message, color = TextSecondary)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDestructive) OfflineRed else IceCyan,
                    contentColor = if (isDestructive) Color.White else Color.Black
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(confirmText, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Text(cancelText, color = TextSecondary)
            }
        }
    )
}
