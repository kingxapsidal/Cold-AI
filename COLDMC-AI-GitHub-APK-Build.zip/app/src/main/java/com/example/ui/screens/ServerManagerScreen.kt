package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ManagedServer
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.StatusIndicatorDot
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerManagerScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val servers by viewModel.servers.collectAsState()
    val activeServer by viewModel.activeServer.collectAsState()
    val panels by viewModel.panels.collectAsState()
    val pingResult by viewModel.minecraftPing.collectAsState()
    val isTesting by viewModel.isTestingConnection.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingServer by remember { mutableStateOf<ManagedServer?>(null) }
    var serverToDelete by remember { mutableStateOf<ManagedServer?>(null) }

    // Dialog state
    var formCustomName by remember { mutableStateOf("") }
    var formIdentifier by remember { mutableStateOf("") }
    var formHost by remember { mutableStateOf("panel.npcraft.bond") }
    var formPort by remember { mutableStateOf("25565") }
    var formPanelId by remember { mutableStateOf(panels.firstOrNull()?.id ?: "") }

    fun openServerDialog(server: ManagedServer?) {
        editingServer = server
        if (server != null) {
            formCustomName = server.customDisplayName
            formIdentifier = server.identifier
            formHost = server.minecraftHost
            formPort = server.minecraftPort.toString()
            formPanelId = server.panelId
        } else {
            formCustomName = "New Minecraft Server"
            formIdentifier = ""
            formHost = "panel.npcraft.bond"
            formPort = "25565"
            formPanelId = panels.firstOrNull()?.id ?: ""
        }
        showAddDialog = true
    }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Multiple Server Management", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Cross-Panel Minecraft Java Instances", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { openServerDialog(null) }) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Server", tint = IceCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { openServerDialog(null) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Server", fontWeight = FontWeight.Bold) },
                containerColor = IceCyan,
                contentColor = Color.Black,
                modifier = Modifier.testTag("fab_add_server")
            )
        }

    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Banner explaining server-to-panel relationship
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, tint = IceCyan, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Multi-Server Inventory",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                "Each server card shows which Pterodactyl panel owns it. Switch servers in one tap to instantly control console, files, and AI commands.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Minecraft Direct SLP Verification Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Minecraft Socket Reachability (Java SLP)", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                text = if (pingResult?.isOnline == true) "ONLINE" else "DISCONNECTED",
                                color = if (pingResult?.isOnline == true) OnlineGreen else OfflineRed,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (pingResult != null) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Latency: ${pingResult!!.latencyMs} ms", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                                Text("Version: ${pingResult!!.version}", color = IceCyan, style = MaterialTheme.typography.bodySmall)
                                Text("Players: ${pingResult!!.playersOnline} / ${pingResult!!.playersMax}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                            if (pingResult!!.motdClean.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("MOTD: ${pingResult!!.motdClean}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                            }
                        } else {
                            Text("No ping query sent yet. Select a server to verify socket.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                    }
                }
            }

            // Server List
            if (servers.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Servers Added Yet", color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Tap 'Add Server' or fetch from connected panels", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else {
                items(servers, key = { it.id }) { server ->
                    val isSelected = server.id == activeServer?.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, if (isSelected) IceCyan else CyberBorder, RoundedCornerShape(14.dp))
                            .clickable { viewModel.selectServer(server.id) },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) DarkCard else DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    StatusIndicatorDot(server.status)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = server.customDisplayName.ifBlank { server.name },
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = "ID: ${server.identifier.ifBlank { "Unassigned" }} • Node: ${server.node}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                if (isSelected) {
                                    Badge(containerColor = IceCyan, contentColor = Color.Black) {
                                        Text("ACTIVE", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Owner Panel Tag
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DarkSurface)
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Cloud, contentDescription = null, tint = IceCyan, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Panel: ${server.panelName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Text(
                                    text = "${server.minecraftHost}:${server.minecraftPort}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = IceCyan
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.selectServer(server.id) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) IceCyan.copy(alpha = 0.2f) else IceCyan,
                                        contentColor = if (isSelected) IceCyan else Color.Black
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(if (isSelected) Icons.Default.Check else Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isSelected) "Selected" else "Select Server", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { openServerDialog(server) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 12.sp)
                                }

                                IconButton(onClick = { serverToDelete = server }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Server", tint = OfflineRed)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    // Add / Edit Server Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    if (editingServer == null) "Add Minecraft Server Instance" else "Edit Server Details",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formCustomName,
                        onValueChange = { formCustomName = it },
                        label = { Text("Display Name") },
                        placeholder = { Text("e.g. Hardcore Survival / Lobby") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_server_name"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )

                    OutlinedTextField(
                        value = formIdentifier,
                        onValueChange = { formIdentifier = it },
                        label = { Text("Pterodactyl Server ID (8 chars)") },
                        placeholder = { Text("e.g. a1b2c3d4") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_server_id"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formHost,
                            onValueChange = { formHost = it },
                            label = { Text("Minecraft Host") },
                            placeholder = { Text("play.example.com") },
                            singleLine = true,
                            modifier = Modifier.weight(0.65f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                        )

                        OutlinedTextField(
                            value = formPort,
                            onValueChange = { formPort = it },
                            label = { Text("Port") },
                            placeholder = { Text("25565") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.35f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                        )
                    }

                    // Panel Selector
                    if (panels.isNotEmpty()) {
                        Text("Associated Panel:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        panels.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (formPanelId == p.id) IceCyan.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable { formPanelId = p.id }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = formPanelId == p.id,
                                    onClick = { formPanelId = p.id },
                                    colors = RadioButtonDefaults.colors(selectedColor = IceCyan)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(p.name, color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parentPanel = panels.find { it.id == formPanelId } ?: panels.firstOrNull()
                        val newOrUpdated = (editingServer ?: ManagedServer()).copy(
                            customDisplayName = formCustomName.ifBlank { "Minecraft Server" },
                            name = formCustomName.ifBlank { "Minecraft Server" },
                            identifier = formIdentifier.trim(),
                            minecraftHost = formHost.trim(),
                            minecraftPort = formPort.toIntOrNull() ?: 25565,
                            panelId = parentPanel?.id ?: "",
                            panelName = parentPanel?.name ?: "Pterodactyl Panel"
                        )
                        viewModel.saveServer(newOrUpdated)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                    modifier = Modifier.testTag("save_server_submit_button")
                ) {
                    Text("Save Server", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Confirmation
    if (serverToDelete != null) {
        ConfirmationDialog(
            title = "Remove Managed Server?",
            message = "This will remove '${serverToDelete!!.customDisplayName}' from your managed server list.",
            confirmText = "Remove Server",
            isDestructive = true,
            onConfirm = {
                viewModel.deleteServer(serverToDelete!!.id)
                serverToDelete = null
            },
            onDismiss = { serverToDelete = null }
        )
    }
}
