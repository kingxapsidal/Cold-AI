package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = IceCyan,
    onPrimary = Color(0xFF001A24),
    primaryContainer = Color(0xFF003644),
    onPrimaryContainer = GlacialFrost,
    secondary = ElectricBlue,
    onSecondary = Color(0xFF00223A),
    secondaryContainer = Color(0xFF0B3354),
    onSecondaryContainer = Color(0xFFD0ECFF),
    tertiary = PurpleAccent,
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkCard,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    error = OfflineRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = DeepCyan,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC7F3F9),
    onPrimaryContainer = Color(0xFF002028),
    secondary = ElectricBlue,
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = OfflineRed,
    onError = Color.White
)

@Composable
fun ColdMcTheme(
    darkTheme: Boolean = true, // Default to stunning Dark Cyber Ice aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
