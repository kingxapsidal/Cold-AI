package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ColdMC Cyber Ice Palette
val IceCyan = Color(0xFF00E5FF)
val IceCyanGlow = Color(0xFF80F2FF)
val DeepCyan = Color(0xFF007A8C)
val ElectricBlue = Color(0xFF38BDF8)
val GlacialFrost = Color(0xFFBAE6FD)

val CyberBlack = Color(0xFF070B14)
val DarkSurface = Color(0xFF0D1527)
val DarkCard = Color(0xFF131F37)
val DarkSurfaceElevated = Color(0xFF1B2B4C)
val CyberBorder = Color(0xFF223A66)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val OnlineGreen = Color(0xFF10B981)
val StartingAmber = Color(0xFFF59E0B)
val StoppingOrange = Color(0xFFF97316)
val OfflineRed = Color(0xFFEF4444)
val PurpleAccent = Color(0xFFA855F7)
