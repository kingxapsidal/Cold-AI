package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiscordConfig
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscordIntegrationScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val currentConfig by viewModel.discordConfig.collectAsState()

    var webhookUrl by remember(currentConfig) { mutableStateOf(currentConfig.webhookUrl) }
    var botToken by remember(currentConfig) { mutableStateOf(currentConfig.botToken) }
    var channelId by remember(currentConfig) { mutableStateOf(currentConfig.channelId) }

    var notifyOnline by remember(currentConfig) { mutableStateOf(currentConfig.notifyOnline) }
    var notifyOffline by remember(currentConfig) { mutableStateOf(currentConfig.notifyOffline) }
    var notifyCrash by remember(currentConfig) { mutableStateOf(currentConfig.notifyCrash) }
    var notifyBackup by remember(currentConfig) { mutableStateOf(currentConfig.notifyBackup) }
    var notifyPlayerJoin by remember(currentConfig) { mutableStateOf(currentConfig.notifyPlayerJoin) }
    var notifyAntiCheat by remember(currentConfig) { mutableStateOf(currentConfig.notifyAntiCheat) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Discord Integration", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Webhooks, Bot Alerts & Moderation Relays", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Info Banner
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = IceCyan, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Real-Time Operations Webhook", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                "Receive instantaneous Discord embeds for server crash events, automated backups, player joins, and AI anti-cheat alerts.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Webhook Configuration Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Discord Webhook / Bot Settings", fontWeight = FontWeight.Bold, color = IceCyan)

                        OutlinedTextField(
                            value = webhookUrl,
                            onValueChange = { webhookUrl = it },
                            label = { Text("Discord Channel Webhook URL") },
                            placeholder = { Text("https://discord.com/api/webhooks/...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("discord_webhook_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                        )

                        OutlinedTextField(
                            value = botToken,
                            onValueChange = { botToken = it },
                            label = { Text("Bot Token (Optional for Slash Commands)") },
                            placeholder = { Text("MTA...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                        )

                        OutlinedTextField(
                            value = channelId,
                            onValueChange = { channelId = it },
                            label = { Text("Channel ID (Optional)") },
                            placeholder = { Text("1234567890...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                        )
                    }
                }
            }

            // Event Toggles Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Notification Event Subscriptions", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(10.dp))

                        val toggles = listOf(
                            Triple("Server Online / Start", "Dispatch embed when Minecraft port responds", notifyOnline) to { v: Boolean -> notifyOnline = v },
                            Triple("Server Offline / Stop", "Alert staff when container stops", notifyOffline) to { v: Boolean -> notifyOffline = v },
                            Triple("Crash & Watchdog Failures", "Immediate alert on OOM or thread deadlocks", notifyCrash) to { v: Boolean -> notifyCrash = v },
                            Triple("Backup Completion", "Notify on snapshot backup created", notifyBackup) to { v: Boolean -> notifyBackup = v },
                            Triple("Player Join / Leave", "Log player connections to chat", notifyPlayerJoin) to { v: Boolean -> notifyPlayerJoin = v },
                            Triple("AI Anti-Cheat Flags", "Forward suspicious reach/speed violations", notifyAntiCheat) to { v: Boolean -> notifyAntiCheat = v }
                        )

                        toggles.forEach { (item, updater) ->
                            val (title, sub, state) = item
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(title, fontWeight = FontWeight.Medium, color = TextPrimary)
                                    Text(sub, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                }
                                Switch(
                                    checked = state,
                                    onCheckedChange = { updater(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = IceCyan,
                                        uncheckedThumbColor = TextMuted,
                                        uncheckedTrackColor = DarkCard
                                    )
                                )
                            }
                            HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }

            // Save & Test Buttons
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val updated = DiscordConfig(
                                webhookUrl = webhookUrl.trim(),
                                botToken = botToken.trim(),
                                channelId = channelId.trim(),
                                notifyOnline = notifyOnline,
                                notifyOffline = notifyOffline,
                                notifyCrash = notifyCrash,
                                notifyBackup = notifyBackup,
                                notifyPlayerJoin = notifyPlayerJoin,
                                notifyAntiCheat = notifyAntiCheat
                            )
                            viewModel.saveDiscordConfig(updated)
                        },
                        modifier = Modifier.weight(1f).height(50.dp).testTag("save_discord_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Config", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            val temp = DiscordConfig(webhookUrl = webhookUrl.trim())
                            viewModel.testDiscordWebhook(temp)
                        },
                        modifier = Modifier.weight(1f).height(50.dp).testTag("test_discord_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = IceCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, IceCyan),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Webhook", fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
