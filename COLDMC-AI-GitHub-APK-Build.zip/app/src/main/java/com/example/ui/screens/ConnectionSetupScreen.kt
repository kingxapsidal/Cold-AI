package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServerAttributes
import com.example.data.model.ServerProfile
import com.example.ui.components.ConfirmationDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionSetupScreen(
    viewModel: ColdMcViewModel,
    onBackOrDone: () -> Unit
) {
    val profiles by viewModel.profiles.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val availableServers by viewModel.availableServers.collectAsState()
    val isTesting by viewModel.isTestingConnection.collectAsState()
    val errorMsg by viewModel.connectionError.collectAsState()
    val successMsg by viewModel.connectionSuccessMsg.collectAsState()
    val minecraftPing by viewModel.minecraftPing.collectAsState()

    // Form inputs initialized from active profile
    var panelUrl by remember(activeProfile) { mutableStateOf(activeProfile?.panelUrl ?: "https://panel.npcraft.bond") }
    var panelUser by remember(activeProfile) { mutableStateOf(activeProfile?.panelUser ?: "") }
    var apiKey by remember(activeProfile) { mutableStateOf(activeProfile?.apiKey ?: "") }
    var showPassword by remember { mutableStateOf(false) }
    var mcHost by remember(activeProfile) { mutableStateOf(activeProfile?.minecraftHost ?: "panel.npcraft.bond") }
    var mcPort by remember(activeProfile) { mutableStateOf(activeProfile?.minecraftPort?.toString() ?: "25565") }
    var serverName by remember(activeProfile) { mutableStateOf(activeProfile?.name ?: "ColdMC Server") }
    var serverIdentifier by remember(activeProfile) { mutableStateOf(activeProfile?.serverIdentifier ?: "") }

    var isGatewayMode by remember(activeProfile) { mutableStateOf(activeProfile?.isFastApiGatewayMode ?: false) }
    var gatewayUrl by remember(activeProfile) { mutableStateOf(activeProfile?.fastApiBaseUrl ?: "http://192.168.1.10:8000") }

    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hosting Connection Setup", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Pterodactyl & Minecraft Client API", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackOrDone) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Info Banner
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(IceCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = IceCyan)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Zero-Exposure Vault Security",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                "Pterodactyl Client API tokens connect directly to your server or local PC gateway. Credentials are never sent to external AI models.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Connection Mode Selector
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Connection Architecture", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !isGatewayMode,
                                onClick = { isGatewayMode = false },
                                label = { Text("Direct Pterodactyl API") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IceCyan,
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = isGatewayMode,
                                onClick = { isGatewayMode = true },
                                label = { Text("Local PC Gateway") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IceCyan,
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Server Profile Details Form
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("1. Profile & Panel Settings", fontWeight = FontWeight.Bold, color = IceCyan)

                        OutlinedTextField(
                            value = serverName,
                            onValueChange = { serverName = it },
                            label = { Text("Server Profile Name") },
                            leadingIcon = { Icon(Icons.Default.Label, contentDescription = null, tint = IceCyan) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("server_name_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IceCyan,
                                unfocusedBorderColor = CyberBorder
                            )
                        )

                        if (!isGatewayMode) {
                            OutlinedTextField(
                                value = panelUrl,
                                onValueChange = { panelUrl = it },
                                label = { Text("Pterodactyl Panel URL") },
                                placeholder = { Text("https://panel.npcraft.bond") },
                                leadingIcon = { Icon(Icons.Default.Cloud, contentDescription = null, tint = IceCyan) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("panel_url_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )

                            OutlinedTextField(
                                value = panelUser,
                                onValueChange = { panelUser = it },
                                label = { Text("Panel Username or Email (Optional)") },
                                placeholder = { Text("admin / player@example.com") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = IceCyan) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("panel_user_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )

                            OutlinedTextField(
                                value = apiKey,
                                onValueChange = { apiKey = it },
                                label = { Text("Pterodactyl Client API Key / Password") },
                                placeholder = { Text("ptlc_xxxxxxxxxxxx...") },
                                leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = IceCyan) },
                                trailingIcon = {
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(
                                            imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (showPassword) "Hide API Key" else "Show API Key",
                                            tint = TextSecondary
                                        )
                                    }
                                },
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_key_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )
                            Text(
                                "Create your API key in Pterodactyl: Click your User Avatar -> Account -> API Credentials -> Create New.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        } else {
                            OutlinedTextField(
                                value = gatewayUrl,
                                onValueChange = { gatewayUrl = it },
                                label = { Text("FastAPI Local Gateway IP & Port") },
                                placeholder = { Text("http://192.168.1.10:8000") },
                                leadingIcon = { Icon(Icons.Default.Lan, contentDescription = null, tint = IceCyan) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("gateway_url_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("2. Minecraft Network Verification", fontWeight = FontWeight.Bold, color = IceCyan)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = mcHost,
                                onValueChange = { mcHost = it },
                                label = { Text("Minecraft Host / IP") },
                                placeholder = { Text("panel.npcraft.bond") },
                                leadingIcon = { Icon(Icons.Default.Storage, contentDescription = null, tint = IceCyan) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(0.65f)
                                    .testTag("mc_host_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )

                            OutlinedTextField(
                                value = mcPort,
                                onValueChange = { mcPort = it },
                                label = { Text("Port") },
                                placeholder = { Text("25565") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .weight(0.35f)
                                    .testTag("mc_port_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IceCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )
                        }

                        // Test & Fetch Button
                        Button(
                            onClick = {
                                val current = activeProfile ?: ServerProfile()
                                val updated = current.copy(
                                    name = serverName.ifBlank { "ColdMC Server" },
                                    panelUrl = panelUrl.trim(),
                                    panelUser = panelUser.trim(),
                                    apiKey = apiKey.trim(),
                                    minecraftHost = mcHost.trim(),
                                    minecraftPort = mcPort.toIntOrNull() ?: 25565,
                                    serverIdentifier = serverIdentifier.trim(),
                                    isFastApiGatewayMode = isGatewayMode,
                                    fastApiBaseUrl = gatewayUrl.trim()
                                )
                                viewModel.saveProfile(updated)
                                viewModel.testConnection(updated)
                            },
                            enabled = !isTesting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("test_connect_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = IceCyan,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isTesting) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Connecting & Validating...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Bolt, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Test Connection & Fetch Servers", fontWeight = FontWeight.Bold)
                            }
                        }

                        // Status Messages
                        if (errorMsg != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = OfflineRed.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth().border(1.dp, OfflineRed, RoundedCornerShape(8.dp))
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = OfflineRed)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(errorMsg ?: "", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        if (successMsg != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = OnlineGreen.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth().border(1.dp, OnlineGreen, RoundedCornerShape(8.dp))
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = OnlineGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(successMsg ?: "", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        // Minecraft Ping Result
                        if (minecraftPing != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (minecraftPing!!.isOnline) OnlineGreen else OfflineRed, RoundedCornerShape(8.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Minecraft TCP Ping",
                                            fontWeight = FontWeight.Bold,
                                            color = if (minecraftPing!!.isOnline) OnlineGreen else OfflineRed
                                        )
                                        Text(
                                            if (minecraftPing!!.isOnline) "${minecraftPing!!.latencyMs} ms" else "Unreachable",
                                            color = if (minecraftPing!!.isOnline) OnlineGreen else OfflineRed,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Version: ${minecraftPing!!.version} | Players: ${minecraftPing!!.playersOnline}/${minecraftPing!!.playersMax}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    if (minecraftPing!!.motdClean.isNotBlank()) {
                                        Text(
                                            "MOTD: ${minecraftPing!!.motdClean}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Server Selector (if servers fetched)
            if (availableServers.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Select Pterodactyl Server Instance", fontWeight = FontWeight.Bold, color = IceCyan)
                            Spacer(modifier = Modifier.height(8.dp))
                            availableServers.forEach { srv ->
                                val isSelected = srv.identifier == serverIdentifier
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) IceCyan.copy(alpha = 0.15f) else Color.Transparent)
                                        .border(1.dp, if (isSelected) IceCyan else CyberBorder, RoundedCornerShape(8.dp))
                                        .clickable {
                                            serverIdentifier = srv.identifier
                                            serverName = srv.name
                                            val current = activeProfile ?: ServerProfile()
                                            viewModel.saveProfile(
                                                current.copy(serverIdentifier = srv.identifier, name = srv.name)
                                            )
                                        }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(srv.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        Text("ID: ${srv.identifier} • Node: ${srv.node}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = IceCyan)
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                        }
                    }
                }
            }

            // Saved Profiles & Disconnect Section
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Saved Server Profiles", fontWeight = FontWeight.Bold, color = TextPrimary)
                            TextButton(
                                onClick = {
                                    val newProf = ServerProfile(name = "New Minecraft Server")
                                    viewModel.saveProfile(newProf)
                                }
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = IceCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Profile", color = IceCyan)
                            }
                        }

                        profiles.forEach { prof ->
                            val isActive = prof.id == activeProfile?.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isActive) DarkCard else Color.Transparent)
                                    .border(1.dp, if (isActive) IceCyan else CyberBorder, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.selectProfile(prof.id) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(prof.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text("${prof.panelUrl} • ${prof.minecraftHost}:${prof.minecraftPort}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                }

                                if (isActive) {
                                    Badge(containerColor = IceCyan, contentColor = Color.Black) {
                                        Text("ACTIVE", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Disconnect & Remove Button
                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("disconnect_remove_credentials_button"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = OfflineRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, OfflineRed.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = OfflineRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Disconnect & Remove Credentials")
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showDeleteConfirmDialog) {
        ConfirmationDialog(
            title = "Disconnect & Remove Credentials?",
            message = "This will wipe the stored Pterodactyl Client API key, server details, and credentials from local storage.",
            confirmText = "Remove & Disconnect",
            isDestructive = true,
            onConfirm = {
                activeProfile?.let { viewModel.removeProfile(it.id) }
                showDeleteConfirmDialog = false
            },
            onDismiss = { showDeleteConfirmDialog = false }
        )
    }
}
