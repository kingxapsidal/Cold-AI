package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActionStatus
import com.example.data.model.AiActionProposal
import com.example.data.model.AiMessage
import com.example.data.model.MessageSender
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAdminScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val messages by viewModel.aiMessages.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()
    var inputPrompt by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val suggestionChips = listOf(
        "Optimize server performance",
        "Check why my server crashed",
        "Check RAM usage",
        "Install EssentialsX",
        "Find plugin conflicts",
        "Restart server"
    )

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(IceCyan),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("COLDMC AI Administrator", color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Autonomous Minecraft Ops Guardian", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .navigationBarsPadding()
                    .padding(8.dp)
            ) {
                // Quick prompt suggestions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestionChips.forEach { chipText ->
                        SuggestionChip(
                            onClick = {
                                viewModel.sendAiPrompt(chipText)
                            },
                            label = { Text(chipText, fontSize = 12.sp, color = GlacialFrost) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = DarkCard),
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = CyberBorder)
                        )
                    }
                }

                // Chat Input Box
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputPrompt,
                        onValueChange = { inputPrompt = it },
                        placeholder = { Text("Ask COLDMC AI anything...", color = TextMuted) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_prompt_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IceCyan,
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (inputPrompt.isNotBlank()) {
                                viewModel.sendAiPrompt(inputPrompt.trim())
                                inputPrompt = ""
                            }
                        },
                        enabled = !isThinking,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(IceCyan)
                            .size(52.dp)
                            .testTag("send_ai_prompt_button")
                    ) {
                        if (isThinking) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                AiMessageBubble(
                    message = msg,
                    onConfirmAction = { proposal -> viewModel.executeAiAction(proposal) },
                    onRejectAction = { proposal -> viewModel.rejectAiAction(proposal) }
                )
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkCard)
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(color = IceCyan, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("COLDMC AI is analyzing server telemetry...", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AiMessageBubble(
    message: AiMessage,
    onConfirmAction: (AiActionProposal) -> Unit,
    onRejectAction: (AiActionProposal) -> Unit
) {
    val isUser = message.sender == MessageSender.USER
    val isSystem = message.sender == MessageSender.SYSTEM

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .border(
                    width = 1.dp,
                    color = if (isUser) IceCyan.copy(alpha = 0.5f) else if (isSystem) StartingAmber else CyberBorder,
                    shape = RoundedCornerShape(14.dp)
                ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF003844) else if (isSystem) Color(0xFF2E2405) else DarkCard
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (!isUser) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isSystem) Icons.Default.Info else Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = if (isSystem) StartingAmber else IceCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSystem) "System Alert" else "COLDMC AI",
                            fontWeight = FontWeight.Bold,
                            color = if (isSystem) StartingAmber else IceCyan,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = message.content,
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )

                // Tool Execution Confirmation Card
                if (message.pendingAction != null) {
                    val proposal = message.pendingAction
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, StartingAmber, RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = StartingAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Permission Required",
                                    fontWeight = FontWeight.Bold,
                                    color = StartingAmber,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(proposal.title, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(proposal.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

                            Spacer(modifier = Modifier.height(10.dp))

                            if (proposal.status == ActionStatus.PENDING) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onConfirmAction(proposal) },
                                        colors = ButtonDefaults.buttonColors(containerColor = StartingAmber, contentColor = Color.Black),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Confirm & Execute", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { onRejectAction(proposal) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Reject", color = TextSecondary, fontSize = 11.sp)
                                    }
                                }
                            } else {
                                Text(
                                    text = "Status: ${proposal.status.name}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (proposal.status == ActionStatus.EXECUTED) OnlineGreen else OfflineRed,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
