package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FileAttributes
import com.example.ui.components.ConfirmationDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManagerScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val currentDir by viewModel.currentDirectory.collectAsState()
    val files by viewModel.currentFiles.collectAsState()
    val isLoading by viewModel.isLoadingFiles.collectAsState()
    val editingFile by viewModel.editingFile.collectAsState()

    var fileToDelete by remember { mutableStateOf<String?>(null) }
    var editorContent by remember(editingFile) { mutableStateOf(editingFile?.second ?: "") }

    LaunchedEffect(Unit) {
        if (files.isEmpty()) {
            viewModel.navigateToDirectory("/")
        }
    }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Server File Manager", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text(currentDir, style = MaterialTheme.typography.bodySmall, color = IceCyan, fontFamily = FontFamily.Monospace)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateToDirectory(currentDir) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = IceCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Directory Path Bar & Up button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentDir != "/" && currentDir.isNotBlank()) {
                    IconButton(
                        onClick = {
                            val parent = currentDir.substringBeforeLast('/', "").ifBlank { "/" }
                            viewModel.navigateToDirectory(parent)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Up", tint = IceCyan)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                Text(
                    text = "Path: $currentDir",
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary,
                    modifier = Modifier.weight(1f)
                )

                // Quick shortcuts
                TextButton(onClick = { viewModel.navigateToDirectory("/plugins") }) {
                    Text("/plugins", color = IceCyan, fontSize = 12.sp)
                }
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = IceCyan)
                }
            } else if (files.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Directory is empty or inaccessible", color = TextSecondary)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(files) { file ->
                        FileItemRow(
                            file = file,
                            onOpen = {
                                if (!file.isFile) {
                                    val nextPath = if (currentDir == "/") "/${file.name}" else "$currentDir/${file.name}"
                                    viewModel.navigateToDirectory(nextPath)
                                } else {
                                    val filePath = if (currentDir == "/") file.name else "$currentDir/${file.name}"
                                    viewModel.openFileForEditing(filePath)
                                }
                            },
                            onDelete = {
                                fileToDelete = file.name
                            }
                        )
                    }
                }
            }
        }
    }

    // Fullscreen File Editor Dialog
    if (editingFile != null) {
        AlertDialog(
            onDismissRequest = { viewModel.closeFileEditor() },
            containerColor = DarkSurface,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        editingFile!!.first.substringAfterLast('/'),
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    IconButton(onClick = { viewModel.closeFileEditor() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }
            },
            text = {
                OutlinedTextField(
                    value = editorContent,
                    onValueChange = { editorContent = it },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("file_content_editor"),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IceCyan,
                        unfocusedBorderColor = CyberBorder
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.saveEditingFile(editorContent) },
                    colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("save_file_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.closeFileEditor() },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Confirmation
    if (fileToDelete != null) {
        val fname = fileToDelete!!
        ConfirmationDialog(
            title = "Delete File?",
            message = "Are you sure you want to delete '$fname'? This action cannot be undone on the server.",
            confirmText = "Delete Permanently",
            isDestructive = true,
            onConfirm = {
                viewModel.deleteFile(fname)
                fileToDelete = null
            },
            onDismiss = { fileToDelete = null }
        )
    }
}

@Composable
fun FileItemRow(
    file: FileAttributes,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
            .clickable { onOpen() },
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = if (!file.isFile) Icons.Default.Folder else when {
                        file.name.endsWith(".jar") -> Icons.Default.Extension
                        file.name.endsWith(".log") -> Icons.Default.Description
                        file.name.endsWith(".properties") || file.name.endsWith(".yml") -> Icons.Default.Settings
                        else -> Icons.Default.InsertDriveFile
                    },
                    contentDescription = null,
                    tint = if (!file.isFile) IceCyan else ElectricBlue,
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = file.name,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = if (!file.isFile) "Folder" else "${file.size / 1024} KB • ${file.mode}",
                        color = TextMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = OfflineRed.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
            }
        }
    }
}
