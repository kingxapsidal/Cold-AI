package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusIndicatorDot
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@Composable
fun DashboardScreen(
    viewModel: ColdMcViewModel,
    onNavigate: (String) -> Unit
) {
    val activeProfile by viewModel.activeProfile.collectAsState()
    val stats by viewModel.resourceStats.collectAsState()
    val ping by viewModel.minecraftPing.collectAsState()
    val isRefreshing by viewModel.isRefreshingStats.collectAsState()

    var pendingSignal by remember { mutableStateOf<String?>(null) }

    val currentState = stats?.currentState ?: (if (ping?.isOnline == true) "running" else "offline")
    val resources = stats?.resources

    val ramUsedMb = (resources?.memoryBytes ?: 0) / (1024 * 1024)
    val diskUsedMb = (resources?.diskBytes ?: 0) / (1024 * 1024)
    val cpuPercent = resources?.cpuAbsolute ?: 0.0

    val rxKb = (resources?.networkRxBytes ?: 0) / 1024
    val txKb = (resources?.networkTxBytes ?: 0) / 1024

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Server Hero Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = activeProfile?.name ?: "ColdMC Java Server",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${activeProfile?.minecraftHost ?: "localhost"}:${activeProfile?.minecraftPort ?: 25565}",
                                style = MaterialTheme.typography.bodySmall,
                                color = IceCyan
                            )
                        }

                        // Status Badge
                        val (statusText, statusBg, statusColor) = when (currentState.lowercase()) {
                            "running" -> Triple("ONLINE", OnlineGreen.copy(alpha = 0.2f), OnlineGreen)
                            "starting" -> Triple("STARTING", StartingAmber.copy(alpha = 0.2f), StartingAmber)
                            "stopping" -> Triple("STOPPING", StoppingOrange.copy(alpha = 0.2f), StoppingOrange)
                            else -> Triple("OFFLINE", OfflineRed.copy(alpha = 0.2f), OfflineRed)
                        }

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(statusBg)
                                .border(1.dp, statusColor, RoundedCornerShape(20.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusIndicatorDot(currentState)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = statusText,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Power Control Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { pendingSignal = "start" },
                            enabled = currentState != "running",
                            colors = ButtonDefaults.buttonColors(
                                containerColor = OnlineGreen,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("power_start_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { pendingSignal = "restart" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StartingAmber,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("power_restart_button")
                        ) {
                            Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restart", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { pendingSignal = "stop" },
                            enabled = currentState != "offline",
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StoppingOrange,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("power_stop_button")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Stop", fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = { pendingSignal = "kill" },
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(OfflineRed.copy(alpha = 0.2f))
                                .border(1.dp, OfflineRed, RoundedCornerShape(10.dp))
                                .testTag("power_kill_button")
                        ) {
                            Icon(Icons.Default.Dangerous, contentDescription = "Kill", tint = OfflineRed)
                        }
                    }
                }
            }
        }

        // Live Resource Gauges Grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    modifier = Modifier.weight(1f),
                    label = "CPU USAGE",
                    value = "${String.format("%.1f", cpuPercent)}%",
                    subValue = if (cpuPercent > 80) "High Load" else "Normal",
                    progress = (cpuPercent / 100.0).toFloat(),
                    progressColor = if (cpuPercent > 80) OfflineRed else IceCyan,
                    icon = Icons.Default.Speed
                )

                MetricCard(
                    modifier = Modifier.weight(1f),
                    label = "MEMORY (RAM)",
                    value = "$ramUsedMb MB",
                    subValue = "Heap in use",
                    progress = ((ramUsedMb % 4096).toFloat() / 4096f).coerceIn(0.1f, 1f),
                    progressColor = ElectricBlue,
                    icon = Icons.Default.Memory
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    modifier = Modifier.weight(1f),
                    label = "STORAGE (DISK)",
                    value = "$diskUsedMb MB",
                    subValue = "Worlds & Plugins",
                    progress = 0.35f,
                    progressColor = PurpleAccent,
                    icon = Icons.Default.Storage
                )

                MetricCard(
                    modifier = Modifier.weight(1f),
                    label = "NETWORK I/O",
                    value = "↓$rxKb ↑$txKb",
                    subValue = "KB Transferred",
                    progress = 0.5f,
                    progressColor = OnlineGreen,
                    icon = Icons.Default.SwapVert
                )
            }
        }

        // Minecraft Ping Details Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = IceCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Minecraft Server Telemetry", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }

                        if (ping != null) {
                            Text(
                                if (ping!!.isOnline) "${ping!!.latencyMs} ms" else "Offline",
                                color = if (ping!!.isOnline) OnlineGreen else OfflineRed,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (ping != null && ping!!.isOnline) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Online Players", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text("${ping!!.playersOnline} / ${ping!!.playersMax}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            }

                            Column {
                                Text("Version", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text(ping!!.version, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }

                            Column {
                                Text("Protocol", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text("${ping!!.protocol}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }

                        if (ping!!.motdClean.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("MOTD", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text(
                                ping!!.motdClean,
                                style = MaterialTheme.typography.bodySmall,
                                color = GlacialFrost
                            )
                        }

                        if (ping!!.playerSample.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Active Players:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ping!!.playerSample.take(5).forEach { name ->
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    } else {
                        Text(
                            text = ping?.error ?: "Awaiting response from Minecraft socket...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Quick Navigation Grid
        item {
            Text("Management Hub", fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Live Console",
                        subtitle = "Send server commands",
                        icon = Icons.Default.Terminal,
                        tint = IceCyan,
                        onClick = { onNavigate("console") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "File Manager",
                        subtitle = "Edit configs & files",
                        icon = Icons.Default.Folder,
                        tint = ElectricBlue,
                        onClick = { onNavigate("files") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Plugins & Mods",
                        subtitle = "Modrinth catalogue",
                        icon = Icons.Default.Extension,
                        tint = PurpleAccent,
                        onClick = { onNavigate("plugins") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "AI Administrator",
                        subtitle = "Intelligent assistant",
                        icon = Icons.Default.AutoAwesome,
                        tint = IceCyan,
                        onClick = { onNavigate("ai") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Security & Anti-Cheat",
                        subtitle = "Player moderation & logs",
                        icon = Icons.Default.Shield,
                        tint = OnlineGreen,
                        onClick = { onNavigate("security") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Backups",
                        subtitle = "Snapshots & restore",
                        icon = Icons.Default.Backup,
                        tint = StartingAmber,
                        onClick = { onNavigate("backups") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Pterodactyl Panels",
                        subtitle = "Unlimited hosting nodes",
                        icon = Icons.Default.CloudQueue,
                        tint = IceCyan,
                        onClick = { onNavigate("panels") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Multiple Servers",
                        subtitle = "Switch instances",
                        icon = Icons.Default.Layers,
                        tint = ElectricBlue,
                        onClick = { onNavigate("servers") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Performance & TPS",
                        subtitle = "MSPT, CPU & Lag logs",
                        icon = Icons.Default.Speed,
                        tint = DeepCyan,
                        onClick = { onNavigate("performance") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Mod Manager",
                        subtitle = "Fabric • Forge • NeoForge",
                        icon = Icons.Default.Build,
                        tint = PurpleAccent,
                        onClick = { onNavigate("mods") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Crash Doctor",
                        subtitle = "AI Stack trace diagnostics",
                        icon = Icons.Default.BugReport,
                        tint = OfflineRed,
                        onClick = { onNavigate("crash_analysis") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Discord Bot Alerts",
                        subtitle = "Webhooks & relays",
                        icon = Icons.Default.NotificationsActive,
                        tint = IceCyan,
                        onClick = { onNavigate("discord") }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Activity History",
                        subtitle = "Security audit logs",
                        icon = Icons.Default.HistoryEdu,
                        tint = TextSecondary,
                        onClick = { onNavigate("activity_history") }
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        title = "Wi-Fi Gateway & Settings",
                        subtitle = "PC bridge & preferences",
                        icon = Icons.Default.Settings,
                        tint = TextPrimary,
                        onClick = { onNavigate("settings") }
                    )
                }
            }
        }


        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Power Confirmation Dialog
    if (pendingSignal != null) {
        val signal = pendingSignal!!
        val isDestructive = signal == "stop" || signal == "kill"
        ConfirmationDialog(
            title = "Confirm Server $signal",
            message = "Are you sure you want to send the '$signal' power signal to ${activeProfile?.name ?: "the server"}?",
            confirmText = signal.uppercase(),
            isDestructive = isDestructive,
            onConfirm = {
                viewModel.sendPowerSignal(signal)
                pendingSignal = null
            },
            onDismiss = { pendingSignal = null }
        )
    }
}

@Composable
fun QuickActionCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                Text(text = subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
        }
    }
}
