package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AntiCheatViolation
import com.example.data.model.PlayerInfo
import com.example.data.model.ViolationSeverity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityHubScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val players by viewModel.modRepo.players.collectAsState()
    val violations by viewModel.modRepo.violations.collectAsState()
    val autoMuteEnabled by viewModel.modRepo.autoMuteEnabled.collectAsState()

    var playerToBan by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Security & Moderation", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Anti-Cheat Telemetry & Policy Vault", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = IceCyan
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Players (${players.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Anti-Cheat (${violations.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Policies & Appeals", fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Players & Whitelist Tab
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Gavel, contentDescription = null, tint = IceCyan)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        "Manage Operator privileges, server whitelist status, and kick/ban operations.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        items(players) { player ->
                            PlayerCardRow(
                                player = player,
                                onToggleOp = { viewModel.modRepo.toggleOp(player.username) },
                                onToggleWhitelist = { viewModel.modRepo.toggleWhitelist(player.username) },
                                onKick = { viewModel.sendConsoleCommand("kick ${player.username} Kicked by administrator") },
                                onBan = { playerToBan = player.username },
                                onUnban = { viewModel.modRepo.unbanPlayer(player.username) }
                            )
                        }
                    }
                }
                1 -> {
                    // Anti-Cheat Violations Tab
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, OfflineRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Shield, contentDescription = null, tint = OfflineRed)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("AI Guardian Anti-Cheat Log", fontWeight = FontWeight.Bold, color = TextPrimary)
                                        Text(
                                            "Heuristic analysis for GrimAC / Vulcan. Zero false-ban guarantee: human verification required before permanent suspension.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }

                        if (violations.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("No active violations detected. Server is clean!", color = OnlineGreen)
                                }
                            }
                        } else {
                            items(violations) { v ->
                                ViolationCard(
                                    violation = v,
                                    onDismiss = { viewModel.modRepo.dismissViolation(v.id) },
                                    onTakeAction = { playerToBan = v.player }
                                )
                            }
                        }
                    }
                }
                2 -> {
                    // Policies & Appeals Tab
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Automated Chat Abuse Policy", fontWeight = FontWeight.Bold, color = IceCyan)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        "Automatically temp-mute players sending repetitive server ads, spam (>4 msg/sec), or excessive caps.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Enable Auto-Mute Guardian", color = TextPrimary, fontWeight = FontWeight.Medium)
                                        Switch(
                                            checked = autoMuteEnabled,
                                            onCheckedChange = { viewModel.modRepo.toggleAutoMute(it) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.Black,
                                                checkedTrackColor = IceCyan
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Human-in-the-Loop Safeguard", fontWeight = FontWeight.Bold, color = OnlineGreen)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        "COLDMC AI enforces a strict policy: AI algorithms may flag, notify staff, or issue temporary 5-minute mutes, but can NEVER permanently ban players autonomously without an operator's manual confirmation.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        item {
                            Text("Player Appeals & Unban Desk", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Spacer(modifier = Modifier.height(8.dp))
                            val bannedPlayers = players.filter { it.isBanned }
                            if (bannedPlayers.isEmpty()) {
                                Text("No pending banned player appeals.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                            } else {
                                bannedPlayers.forEach { bp ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, OfflineRed.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(bp.username, fontWeight = FontWeight.Bold, color = TextPrimary)
                                                Text("Status: Permanently Banned", style = MaterialTheme.typography.labelSmall, color = OfflineRed)
                                            }
                                            Button(
                                                onClick = {
                                                    viewModel.modRepo.unbanPlayer(bp.username)
                                                    viewModel.sendConsoleCommand("pardon ${bp.username}")
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = OnlineGreen, contentColor = Color.Black),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Unban & Pardon", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (playerToBan != null) {
        val target = playerToBan!!
        ConfirmationDialog(
            title = "Ban Player '$target'?",
            message = "This will kick '$target' and permanently ban them from connecting to the server.",
            confirmText = "Confirm Ban",
            isDestructive = true,
            onConfirm = {
                viewModel.modRepo.banPlayer(target)
                viewModel.sendConsoleCommand("ban $target Banned by Server Operator via COLDMC AI")
                playerToBan = null
            },
            onDismiss = { playerToBan = null }
        )
    }
}

@Composable
fun PlayerCardRow(
    player: PlayerInfo,
    onToggleOp: () -> Unit,
    onToggleWhitelist: () -> Unit,
    onKick: () -> Unit,
    onBan: () -> Unit,
    onUnban: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(if (player.isOnline) OnlineGreen else TextMuted)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(player.username, fontWeight = FontWeight.Bold, color = TextPrimary)
                    if (player.isOp) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = StartingAmber, contentColor = Color.Black) {
                            Text("OP", fontWeight = FontWeight.Bold)
                        }
                    }
                    if (player.isBanned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = OfflineRed, contentColor = Color.White) {
                            Text("BANNED", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (player.isOnline) {
                    Text("${player.ping} ms", style = MaterialTheme.typography.labelSmall, color = GlacialFrost)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleOp,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (player.isOp) "Deop" else "Make OP", fontSize = 11.sp, color = if (player.isOp) StartingAmber else TextSecondary)
                }

                OutlinedButton(
                    onClick = onToggleWhitelist,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (player.isWhitelisted) "Un-whitelist" else "Whitelist", fontSize = 11.sp, color = IceCyan)
                }

                if (!player.isBanned) {
                    Button(
                        onClick = onKick,
                        colors = ButtonDefaults.buttonColors(containerColor = StoppingOrange, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Kick", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onBan,
                        colors = ButtonDefaults.buttonColors(containerColor = OfflineRed, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Ban", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onUnban,
                        colors = ButtonDefaults.buttonColors(containerColor = OnlineGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Pardon", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ViolationCard(
    violation: AntiCheatViolation,
    onDismiss: () -> Unit,
    onTakeAction: () -> Unit
) {
    val sevColor = when (violation.severity) {
        ViolationSeverity.CRITICAL -> OfflineRed
        ViolationSeverity.HIGH -> StoppingOrange
        ViolationSeverity.MEDIUM -> StartingAmber
        ViolationSeverity.LOW -> GlacialFrost
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, sevColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = sevColor, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(violation.player, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Badge(containerColor = sevColor.copy(alpha = 0.2f), contentColor = sevColor) {
                    Text(violation.severity.name, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(violation.checkName, fontWeight = FontWeight.Medium, color = IceCyan, style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(2.dp))
            Text(violation.details, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text("Dismiss", color = TextMuted, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onTakeAction,
                    colors = ButtonDefaults.buttonColors(containerColor = OfflineRed, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("Sanction Player", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
