package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val activeProfile by viewModel.activeProfile.collectAsState()

    var isGatewayMode by remember(activeProfile) { mutableStateOf(activeProfile?.isFastApiGatewayMode ?: false) }
    var gatewayUrl by remember(activeProfile) { mutableStateOf(activeProfile?.fastApiBaseUrl ?: "http://192.168.1.10:8000") }
    var autoPollStats by remember { mutableStateOf(true) }
    var highContrastCyber by remember { mutableStateOf(true) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Settings & Wi-Fi Gateway", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Local Network Bridge & Preferences", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Local Wi-Fi Connection Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = IceCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Local Wi-Fi PC Gateway", fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                        }

                        Text(
                            "Run the Python FastAPI backend on your Windows PC (`python main.py`). Enter your PC's Wi-Fi IP address below to manage servers without direct external panel reachability.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Use Local PC Gateway", fontWeight = FontWeight.Medium, color = TextPrimary)
                            Switch(
                                checked = isGatewayMode,
                                onCheckedChange = { isGatewayMode = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = IceCyan,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = DarkCard
                                )
                            )
                        }

                        if (isGatewayMode) {
                            OutlinedTextField(
                                value = gatewayUrl,
                                onValueChange = { gatewayUrl = it },
                                label = { Text("PC Gateway IP & Port") },
                                placeholder = { Text("http://192.168.1.10:8000") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("settings_gateway_url_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                            )

                            Button(
                                onClick = {
                                    val current = activeProfile ?: return@Button
                                    val updated = current.copy(
                                        isFastApiGatewayMode = true,
                                        fastApiBaseUrl = gatewayUrl.trim()
                                    )
                                    viewModel.saveProfile(updated)
                                    viewModel.testConnection(updated)
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.NetworkCheck, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test & Save Wi-Fi Gateway", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // General App Preferences
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Application Preferences", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Auto Telemetry Polling", fontWeight = FontWeight.Medium, color = TextPrimary)
                                Text("Query container memory/CPU every 8 seconds", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Switch(
                                checked = autoPollStats,
                                onCheckedChange = { autoPollStats = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = IceCyan,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = DarkCard
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Cyber Cyan Dark Theme", fontWeight = FontWeight.Medium, color = TextPrimary)
                                Text("OLED true-black with neon cyan accents", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Switch(
                                checked = highContrastCyber,
                                onCheckedChange = { highContrastCyber = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = IceCyan,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = DarkCard
                                )
                            )
                        }
                    }
                }
            }

            // Vault Security Information
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = OnlineGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Security & Privacy Vault", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "• Zero-Exposure: Panel API keys are never submitted to generative models or external third parties.\n" +
                            "• Local Storage: Credentials remain isolated within private Android app storage.\n" +
                            "• Controlled Actions: Destructive power commands (stop, restart, kill, ban) always mandate operator confirmation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            // Version info
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("COLDMC AI • Version 2.4.0", color = TextMuted, fontSize = 12.sp)
                        Text("Autonomous Minecraft Java Server Management", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
