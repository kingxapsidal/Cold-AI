package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ModrinthHit
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PluginManagerScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("EssentialsX") }
    val hits by viewModel.modrinthHits.collectAsState()
    val isSearching by viewModel.isSearchingModrinth.collectAsState()
    val installedPlugins by viewModel.installedPlugins.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.navigateToDirectory("/plugins")
    }

    val popularPlugins = listOf("EssentialsX", "LuckPerms", "Vault", "WorldEdit", "ViaVersion", "Spark", "Geyser", "CoreProtect")

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Minecraft Java Plugins & Mods", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Modrinth Catalogue & Installer", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = IceCyan
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Modrinth Catalogue", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        viewModel.navigateToDirectory("/plugins")
                    },
                    text = { Text("Installed (${installedPlugins.size})", fontWeight = FontWeight.Bold) }
                )
            }

            if (selectedTab == 0) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Search bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search plugins (e.g. EssentialsX, LuckPerms)...", color = TextMuted) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = IceCyan) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { viewModel.searchPlugins(searchQuery) }) {
                                        Icon(Icons.Default.ArrowForward, contentDescription = "Search", tint = IceCyan)
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("plugin_search_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IceCyan,
                                unfocusedBorderColor = CyberBorder
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick suggestions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        popularPlugins.take(4).forEach { p ->
                            FilterChip(
                                selected = searchQuery == p,
                                onClick = {
                                    searchQuery = p
                                    viewModel.searchPlugins(p)
                                },
                                label = { Text(p, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IceCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isSearching) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = IceCyan)
                        }
                    } else if (hits.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No plugins found for '$searchQuery'", color = TextSecondary)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(hits) { hit ->
                                ModrinthPluginCard(
                                    hit = hit,
                                    onInstall = { viewModel.installModrinthProject(hit) }
                                )
                            }
                        }
                    }
                }
            } else {
                // Installed plugins tab
                if (installedPlugins.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ExtensionOff, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No plugins detected in /plugins folder", color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Install plugins using the Modrinth Catalogue tab", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(installedPlugins) { file ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CyberBorder, RoundedCornerShape(10.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCard)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = OnlineGreen)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(file.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                            Text("${file.size / 1024} KB • JAR Plugin", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                        }
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteFile(file.name) }
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Uninstall", tint = OfflineRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModrinthPluginCard(
    hit: ModrinthHit,
    onInstall: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(hit.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("by ${hit.slug} • ${hit.downloads} downloads", style = MaterialTheme.typography.labelSmall, color = IceCyan)
                }

                Button(
                    onClick = onInstall,
                    colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("install_plugin_${hit.slug}")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Install", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = hit.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2
            )

            if (hit.categories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    hit.categories.take(3).forEach { cat ->
                        AssistChip(
                            onClick = {},
                            label = { Text(cat, fontSize = 10.sp, color = GlacialFrost) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceElevated)
                        )
                    }
                }
            }
        }
    }
}
