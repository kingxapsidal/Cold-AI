package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AiRepository
import com.example.data.repository.ModerationRepository
import com.example.data.repository.ServerRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ColdMcViewModel(application: Application) : AndroidViewModel(application) {

    val serverRepo = ServerRepository(application.applicationContext)
    val aiRepo = AiRepository(serverRepo)
    val modRepo = ModerationRepository()

    val profiles: StateFlow<List<ServerProfile>> = serverRepo.profiles
    val activeProfile: StateFlow<ServerProfile?> = serverRepo.activeProfile
    val availableServers: StateFlow<List<ServerAttributes>> = serverRepo.availableServers

    // Multi-Panel & Multi-Server StateFlows
    val panels: StateFlow<List<PterodactylPanel>> = serverRepo.panels
    val activePanel: StateFlow<PterodactylPanel?> = serverRepo.activePanel
    val servers: StateFlow<List<ManagedServer>> = serverRepo.servers
    val activeServer: StateFlow<ManagedServer?> = serverRepo.activeServer
    val auditLogs: StateFlow<List<AuditLogEntry>> = serverRepo.auditLogs
    val discordConfig: StateFlow<DiscordConfig> = serverRepo.discordConfig

    // Mods StateFlow
    private val _modrinthModHits = MutableStateFlow<List<ModrinthHit>>(emptyList())
    val modrinthModHits: StateFlow<List<ModrinthHit>> = _modrinthModHits.asStateFlow()

    private val _isSearchingMods = MutableStateFlow(false)
    val isSearchingMods: StateFlow<Boolean> = _isSearchingMods.asStateFlow()

    // Panel Testing State
    private val _isTestingPanel = MutableStateFlow(false)
    val isTestingPanel: StateFlow<Boolean> = _isTestingPanel.asStateFlow()

    // Connection testing state
    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()


    private val _connectionError = MutableStateFlow<String?>(null)
    val connectionError: StateFlow<String?> = _connectionError.asStateFlow()

    private val _connectionSuccessMsg = MutableStateFlow<String?>(null)
    val connectionSuccessMsg: StateFlow<String?> = _connectionSuccessMsg.asStateFlow()

    // Dashboard Telemetry
    private val _resourceStats = MutableStateFlow<ResourceStats?>(null)
    val resourceStats: StateFlow<ResourceStats?> = _resourceStats.asStateFlow()

    private val _minecraftPing = MutableStateFlow<MinecraftPingResult?>(null)
    val minecraftPing: StateFlow<MinecraftPingResult?> = _minecraftPing.asStateFlow()

    private val _isRefreshingStats = MutableStateFlow(false)
    val isRefreshingStats: StateFlow<Boolean> = _isRefreshingStats.asStateFlow()

    // Console
    private val _consoleLogs = MutableStateFlow<List<String>>(
        listOf(
            "[10:00:01 INFO]: Loading Minecraft server properties...",
            "[10:00:02 INFO]: Starting Minecraft server on *:25565",
            "[10:00:03 INFO]: Using default channel type",
            "[10:00:05 INFO]: [COLDMC] Initializing AI Server Guardian v2.4",
            "[10:00:08 INFO]: Preparing level 'world'...",
            "[10:00:12 INFO]: [Paper] Running Paper version 1.21.1-R0.1-SNAPSHOT",
            "[10:00:15 INFO]: Done (14.234s)! For help, type 'help'"
        )
    )
    val consoleLogs: StateFlow<List<String>> = _consoleLogs.asStateFlow()

    // File Manager
    private val _currentDirectory = MutableStateFlow("/")
    val currentDirectory: StateFlow<String> = _currentDirectory.asStateFlow()

    private val _currentFiles = MutableStateFlow<List<FileAttributes>>(emptyList())
    val currentFiles: StateFlow<List<FileAttributes>> = _currentFiles.asStateFlow()

    private val _isLoadingFiles = MutableStateFlow(false)
    val isLoadingFiles: StateFlow<Boolean> = _isLoadingFiles.asStateFlow()

    private val _editingFile = MutableStateFlow<Pair<String, String>?>(null) // (path, content)
    val editingFile: StateFlow<Pair<String, String>?> = _editingFile.asStateFlow()

    // Plugins & Mods
    private val _modrinthSearchQuery = MutableStateFlow("")
    val modrinthSearchQuery: StateFlow<String> = _modrinthSearchQuery.asStateFlow()

    private val _modrinthHits = MutableStateFlow<List<ModrinthHit>>(emptyList())
    val modrinthHits: StateFlow<List<ModrinthHit>> = _modrinthHits.asStateFlow()

    private val _isSearchingModrinth = MutableStateFlow(false)
    val isSearchingModrinth: StateFlow<Boolean> = _isSearchingModrinth.asStateFlow()

    private val _installedPlugins = MutableStateFlow<List<FileAttributes>>(emptyList())
    val installedPlugins: StateFlow<List<FileAttributes>> = _installedPlugins.asStateFlow()

    // AI Assistant
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(
        listOf(
            AiMessage(
                sender = MessageSender.AI,
                content = "👋 Hello! I am **COLDMC AI**, your intelligent Minecraft server administrator.\n\n" +
                        "Connected to **Pterodactyl Client API**. You can ask me to check server health, analyze crash logs, optimize performance, or install plugins."
            )
        )
    )
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Backups
    private val _backupsList = MutableStateFlow<List<BackupAttributes>>(emptyList())
    val backupsList: StateFlow<List<BackupAttributes>> = _backupsList.asStateFlow()

    // Operation Feedback Snackbar
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private var pollJob: Job? = null

    init {
        // Seed default panel and server if empty
        if (serverRepo.panels.value.isEmpty()) {
            val defaultPanel = PterodactylPanel(
                id = "panel-default",
                name = "NPCraft Hosting",
                url = "https://panel.npcraft.bond",
                status = "Connected",
                isConnected = true,
                serverCount = 1
            )
            serverRepo.addOrUpdatePanel(defaultPanel)
            val defaultServer = ManagedServer(
                id = "srv-default",
                panelId = defaultPanel.id,
                panelName = defaultPanel.name,
                identifier = "coldmc01",
                name = "COLDMC Survival",
                customDisplayName = "Survival Server (1.21.1)",
                node = "Node-Alpha",
                minecraftHost = "panel.npcraft.bond",
                minecraftPort = 25565,
                status = "running"
            )
            serverRepo.addOrUpdateServer(defaultServer)
        }

        // Start polling active server stats
        startTelemetryPolling()
        searchPlugins("EssentialsX")
        searchMods("Lithium", "fabric")
    }


    private fun startTelemetryPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                val profile = activeProfile.value
                if (profile != null) {
                    refreshTelemetry(profile)
                }
                delay(8000)
            }
        }
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun saveProfile(profile: ServerProfile) {
        serverRepo.saveProfile(profile)
        showSnackbar("Saved profile '${profile.name}'")
        refreshTelemetry(profile)
    }

    fun selectProfile(profileId: String) {
        serverRepo.selectActiveProfile(profileId)
        val profile = activeProfile.value
        if (profile != null) {
            refreshTelemetry(profile)
        }
    }

    fun removeProfile(profileId: String) {
        serverRepo.removeProfile(profileId)
        showSnackbar("Profile removed")
    }

    fun testConnection(profile: ServerProfile) {
        viewModelScope.launch {
            _isTestingConnection.value = true
            _connectionError.value = null
            _connectionSuccessMsg.value = null

            // 1. Test Pterodactyl / FastAPI connection
            val pteroResult = serverRepo.testConnection(profile)
            pteroResult.fold(
                onSuccess = { servers ->
                    val serverCount = servers.size
                    _connectionSuccessMsg.value = "Connected successfully! Retrieved $serverCount server(s)."
                    // If no identifier was picked and servers exist, auto-select first
                    if (profile.serverIdentifier.isBlank() && servers.isNotEmpty()) {
                        val first = servers.first()
                        val updated = profile.copy(
                            serverIdentifier = first.identifier,
                            name = if (profile.name.isBlank()) first.name else profile.name
                        )
                        serverRepo.saveProfile(updated)
                    }
                },
                onFailure = { err ->
                    _connectionError.value = err.localizedMessage ?: "Connection error"
                }
            )

            // 2. Test Minecraft Server TCP Ping
            val ping = serverRepo.pingMinecraftServer(profile.minecraftHost, profile.minecraftPort)
            _minecraftPing.value = ping

            _isTestingConnection.value = false
        }
    }

    fun refreshTelemetry(profile: ServerProfile? = activeProfile.value) {
        if (profile == null) return
        viewModelScope.launch {
            _isRefreshingStats.value = true

            // Fetch resources
            val resResult = serverRepo.fetchServerResources(profile)
            resResult.onSuccess { stats ->
                _resourceStats.value = stats
            }

            // Ping Minecraft port
            val ping = serverRepo.pingMinecraftServer(profile.minecraftHost, profile.minecraftPort)
            _minecraftPing.value = ping

            _isRefreshingStats.value = false
        }
    }

    fun sendPowerSignal(signal: String) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Sending signal '$signal' to server...")
            val result = serverRepo.sendPowerSignal(profile, signal)
            result.fold(
                onSuccess = {
                    showSnackbar("Power signal '$signal' dispatched")
                    delay(1500)
                    refreshTelemetry(profile)
                },
                onFailure = { err ->
                    showSnackbar("Failed: ${err.localizedMessage}")
                }
            )
        }
    }

    fun sendConsoleCommand(cmd: String) {
        if (cmd.isBlank()) return
        val profile = activeProfile.value ?: return

        // Add to local terminal display
        val current = _consoleLogs.value.toMutableList()
        current.add("> $cmd")
        _consoleLogs.value = current

        viewModelScope.launch {
            val result = serverRepo.sendCommand(profile, cmd)
            result.fold(
                onSuccess = {
                    val updated = _consoleLogs.value.toMutableList()
                    updated.add("[COLDMC INFO]: Executed '$cmd'")
                    _consoleLogs.value = updated
                },
                onFailure = { err ->
                    val updated = _consoleLogs.value.toMutableList()
                    updated.add("[COLDMC ERROR]: Command failed - ${err.localizedMessage}")
                    _consoleLogs.value = updated
                }
            )
        }
    }

    // Files
    fun navigateToDirectory(directory: String) {
        val profile = activeProfile.value ?: return
        _currentDirectory.value = directory
        viewModelScope.launch {
            _isLoadingFiles.value = true
            val res = serverRepo.listFiles(profile, directory)
            res.fold(
                onSuccess = { list ->
                    _currentFiles.value = list
                    if (directory == "/plugins" || directory == "plugins") {
                        _installedPlugins.value = list
                    }
                },
                onFailure = { err ->
                    showSnackbar("Failed to list files: ${err.localizedMessage}")
                }
            )
            _isLoadingFiles.value = false
        }
    }

    fun openFileForEditing(filePath: String) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Reading $filePath...")
            val res = serverRepo.getFileContent(profile, filePath)
            res.fold(
                onSuccess = { content ->
                    _editingFile.value = Pair(filePath, content)
                },
                onFailure = { err ->
                    showSnackbar("Failed to open file: ${err.localizedMessage}")
                }
            )
        }
    }

    fun closeFileEditor() {
        _editingFile.value = null
    }

    fun saveEditingFile(content: String) {
        val editing = _editingFile.value ?: return
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Saving ${editing.first}...")
            val res = serverRepo.saveFileContent(profile, editing.first, content)
            res.fold(
                onSuccess = {
                    showSnackbar("File saved successfully!")
                    _editingFile.value = null
                    navigateToDirectory(_currentDirectory.value)
                },
                onFailure = { err ->
                    showSnackbar("Failed to save: ${err.localizedMessage}")
                }
            )
        }
    }

    fun deleteFile(filename: String) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Deleting $filename...")
            val res = serverRepo.deleteFile(profile, _currentDirectory.value, filename)
            res.fold(
                onSuccess = {
                    showSnackbar("Deleted $filename")
                    navigateToDirectory(_currentDirectory.value)
                },
                onFailure = { err ->
                    showSnackbar("Delete failed: ${err.localizedMessage}")
                }
            )
        }
    }

    // Modrinth Plugins
    fun searchPlugins(query: String) {
        _modrinthSearchQuery.value = query
        viewModelScope.launch {
            _isSearchingModrinth.value = true
            val res = serverRepo.searchModrinth(query, "plugin")
            res.fold(
                onSuccess = { hits ->
                    _modrinthHits.value = hits
                },
                onFailure = { err ->
                    showSnackbar("Search error: ${err.localizedMessage}")
                }
            )
            _isSearchingModrinth.value = false
        }
    }

    fun installModrinthProject(hit: ModrinthHit) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Fetching versions for ${hit.title}...")
            val verRes = serverRepo.getModrinthVersions(hit.slug)
            val version = verRes.getOrNull()?.firstOrNull()
            val downloadFile = version?.files?.firstOrNull()

            if (downloadFile == null) {
                showSnackbar("Could not find download file for ${hit.title}")
                return@launch
            }

            showSnackbar("Installing ${downloadFile.filename} to /plugins...")
            val installRes = serverRepo.installPluginFromUrl(profile, downloadFile.url, "/plugins")
            installRes.fold(
                onSuccess = {
                    showSnackbar("Installed ${hit.title}! Restart server to load plugin.")
                },
                onFailure = { err ->
                    showSnackbar("Install failed: ${err.localizedMessage}")
                }
            )
        }
    }

    // AI Assistant
    fun sendAiPrompt(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = AiMessage(sender = MessageSender.USER, content = prompt)
        _aiMessages.value = _aiMessages.value + userMsg

        viewModelScope.launch {
            _isAiThinking.value = true
            val reply = aiRepo.processUserPrompt(
                profile = activeProfile.value,
                prompt = prompt,
                currentStats = _resourceStats.value,
                pingResult = _minecraftPing.value,
                recentLogs = _consoleLogs.value
            )
            _aiMessages.value = _aiMessages.value + reply
            _isAiThinking.value = false
        }
    }

    fun executeAiAction(proposal: AiActionProposal) {
        val profile = activeProfile.value ?: return
        proposal.status = ActionStatus.CONFIRMED

        viewModelScope.launch {
            when (proposal.actionType) {
                ActionType.START_SERVER -> {
                    sendPowerSignal("start")
                    serverRepo.logAudit("COLDMC AI", "Start Server", profile.name, "SUCCESS", "Dispatched start signal")
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "🚀 **AI Action Executed**: Server start power signal dispatched."
                    )
                }
                ActionType.RESTART_SERVER -> {
                    sendPowerSignal("restart")
                    serverRepo.logAudit("COLDMC AI", "Restart Server", profile.name, "SUCCESS", "Dispatched restart signal")
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "✅ **AI Action Executed**: Server restart signal sent."
                    )
                }
                ActionType.STOP_SERVER -> {
                    sendPowerSignal("stop")
                    serverRepo.logAudit("COLDMC AI", "Stop Server", profile.name, "SUCCESS", "Dispatched stop signal")
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "🛑 **AI Action Executed**: Server stop signal sent."
                    )
                }
                ActionType.CREATE_BACKUP -> {
                    createBackup(proposal.payload)
                    serverRepo.logAudit("COLDMC AI", "Create Backup", profile.name, "SUCCESS", proposal.payload)
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "💾 **AI Action Executed**: Server snapshot backup scheduled (${proposal.payload})."
                    )
                }
                ActionType.INSTALL_PLUGIN -> {
                    showSnackbar("AI downloading plugin...")
                    serverRepo.installPluginFromUrl(profile, proposal.payload, "/plugins")
                    serverRepo.logAudit("COLDMC AI", "Install Plugin", profile.name, "SUCCESS", proposal.payload)
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "📦 **AI Action Executed**: Plugin downloaded and placed in /plugins/."
                    )
                }
                ActionType.INSTALL_MOD -> {
                    showSnackbar("AI downloading mod...")
                    serverRepo.installPluginFromUrl(profile, proposal.payload, "/mods")
                    serverRepo.logAudit("COLDMC AI", "Install Mod", profile.name, "SUCCESS", proposal.payload)
                    _aiMessages.value = _aiMessages.value + AiMessage(
                        sender = MessageSender.SYSTEM,
                        content = "⚙️ **AI Action Executed**: Mod file placed in /mods/."
                    )
                }
                ActionType.EXECUTE_COMMAND -> {
                    sendConsoleCommand(proposal.payload)
                    serverRepo.logAudit("COLDMC AI", "Console Command", profile.name, "SUCCESS", proposal.payload)
                }
                ActionType.DELETE_FILE -> {
                    deleteFile(proposal.payload)
                    serverRepo.logAudit("COLDMC AI", "Delete File", profile.name, "SUCCESS", proposal.payload)
                }
                ActionType.BAN_PLAYER -> {
                    modRepo.banPlayer(proposal.payload)
                    sendConsoleCommand("ban ${proposal.payload} Banned by COLDMC AI Guardian")
                    serverRepo.logAudit("COLDMC AI", "Ban Player: ${proposal.payload}", profile.name, "SUCCESS", "Violation enforcement")
                }
            }
            proposal.status = ActionStatus.EXECUTED
        }
    }

    // --- Multi-Panel ViewModel Methods ---
    fun savePanel(panel: PterodactylPanel) {
        serverRepo.addOrUpdatePanel(panel)
        showSnackbar("Saved panel '${panel.name}'")
    }

    fun deletePanel(panelId: String) {
        serverRepo.deletePanel(panelId)
        showSnackbar("Panel removed")
    }

    fun selectPanel(panelId: String) {
        serverRepo.selectActivePanel(panelId)
    }

    fun testPanel(panel: PterodactylPanel) {
        viewModelScope.launch {
            _isTestingPanel.value = true
            val res = serverRepo.testPanelConnection(panel)
            res.fold(
                onSuccess = { servers ->
                    showSnackbar("Panel connected! Found ${servers.size} server(s).")
                },
                onFailure = { err ->
                    showSnackbar("Panel test failed: ${err.localizedMessage}")
                }
            )
            _isTestingPanel.value = false
        }
    }

    // --- Multi-Server ViewModel Methods ---
    fun saveServer(server: ManagedServer) {
        serverRepo.addOrUpdateServer(server)
        showSnackbar("Saved server '${server.customDisplayName}'")
        serverRepo.selectActiveServer(server.id)
    }

    fun deleteServer(serverId: String) {
        serverRepo.deleteServer(serverId)
        showSnackbar("Server removed")
    }

    fun selectServer(serverId: String) {
        serverRepo.selectActiveServer(serverId)
        activeProfile.value?.let { refreshTelemetry(it) }
    }

    // --- Discord Integration Methods ---
    fun saveDiscordConfig(config: DiscordConfig) {
        serverRepo.saveDiscordConfig(config)
        showSnackbar("Discord notification preferences saved")
    }

    fun testDiscordWebhook(config: DiscordConfig) {
        viewModelScope.launch {
            showSnackbar("Dispatching test notification to Discord...")
            val res = serverRepo.sendDiscordWebhookTest(config)
            res.fold(
                onSuccess = {
                    showSnackbar("Discord notification sent successfully!")
                },
                onFailure = { err ->
                    showSnackbar("Discord dispatch failed: ${err.localizedMessage}")
                }
            )
        }
    }

    // --- Audit Logs ---
    fun clearAuditLogs() {
        serverRepo.clearAuditLogs()
        showSnackbar("Activity history cleared")
    }

    // --- Mods Discovery Methods ---
    fun searchMods(query: String, loader: String = "fabric") {
        viewModelScope.launch {
            _isSearchingMods.value = true
            val res = serverRepo.searchModrinthMods(query, loader)
            res.fold(
                onSuccess = { hits ->
                    _modrinthModHits.value = hits
                },
                onFailure = { err ->
                    showSnackbar("Mod search failed: ${err.localizedMessage}")
                }
            )
            _isSearchingMods.value = false
        }
    }

    fun installMod(hit: ModrinthHit) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Fetching mod files for ${hit.title}...")
            val verRes = serverRepo.getModrinthVersions(hit.slug)
            val version = verRes.getOrNull()?.firstOrNull()
            val downloadFile = version?.files?.firstOrNull()

            if (downloadFile == null) {
                showSnackbar("Could not locate download file for ${hit.title}")
                return@launch
            }

            showSnackbar("Installing ${downloadFile.filename} to /mods...")
            val installRes = serverRepo.installPluginFromUrl(profile, downloadFile.url, "/mods")
            installRes.fold(
                onSuccess = {
                    serverRepo.logAudit("Operator", "Installed Mod: ${hit.title}", profile.name, "SUCCESS", downloadFile.filename)
                    showSnackbar("Installed ${hit.title} into /mods/! Restart to load.")
                },
                onFailure = { err ->
                    showSnackbar("Mod install failed: ${err.localizedMessage}")
                }
            )
        }
    }


    fun rejectAiAction(proposal: AiActionProposal) {
        proposal.status = ActionStatus.REJECTED
        _aiMessages.value = _aiMessages.value + AiMessage(
            sender = MessageSender.SYSTEM,
            content = "❌ **Action Cancelled**: Operation '${proposal.title}' was aborted by user."
        )
    }

    // Backups
    fun loadBackups() {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            val res = serverRepo.listBackups(profile)
            res.fold(
                onSuccess = { list ->
                    _backupsList.value = list
                },
                onFailure = { err ->
                    showSnackbar("Failed to list backups: ${err.localizedMessage}")
                }
            )
        }
    }

    fun createBackup(backupName: String) {
        val profile = activeProfile.value ?: return
        viewModelScope.launch {
            showSnackbar("Creating backup '$backupName'...")
            val res = serverRepo.createBackup(profile, backupName)
            res.fold(
                onSuccess = {
                    showSnackbar("Backup created successfully!")
                    loadBackups()
                },
                onFailure = { err ->
                    showSnackbar("Backup failed: ${err.localizedMessage}")
                }
            )
        }
    }
}
