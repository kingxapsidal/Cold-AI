package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CrashReportAnalysis
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrashAnalysisScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val logs by viewModel.consoleLogs.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()

    var isAnalyzing by remember { mutableStateOf(false) }

    val initialAnalysis = remember {
        listOf(
            CrashReportAnalysis(
                timestamp = "Recent Watchdog Scan",
                exceptionType = "Java Heap Warning / Memory Limit (OOM Risk)",
                culpritModule = "Allocated Pterodactyl Container RAM",
                summary = "The container is approaching 85% of allocated heap. If garbage collection cannot reclaim space, the kernel OOM killer will terminate the Java process (Exit Code 137).",
                suggestedFix = "1. Allocate at least 4GB RAM in panel limits.\n2. Add Aikar's Flags in Startup parameters: `-XX:+UseG1GC -XX:MaxGCPauseMillis=200`.\n3. Lower view-distance to 6 in `server.properties`.",
                severity = "HIGH",
                stackTraceSnippet = "java.lang.OutOfMemoryError: Java heap space\n\tat net.minecraft.world.level.chunk.LevelChunk.getBlockState(LevelChunk.java:182)\n\tat net.minecraft.server.level.ServerChunkCache.tick(ServerChunkCache.java:412)"
            ),
            CrashReportAnalysis(
                timestamp = "Bytecode Compatibility Scan",
                exceptionType = "UnsupportedClassVersionError",
                culpritModule = "Java Runtime Version Mismatch",
                summary = "Minecraft 1.20.5+ and 1.21 require Java 21 (class file version 65.0). Using Java 17 will cause plugins like ViaVersion or Paper to fail on initialization.",
                suggestedFix = "In Pterodactyl Panel -> Startup Settings -> Change Docker Image to `ghcr.io/pterodactyl/yolks:java_21`.",
                severity = "CRITICAL",
                stackTraceSnippet = "java.lang.UnsupportedClassVersionError: com/viaversion/viaversion/ViaVersion has been compiled by a more recent version of the Java Runtime (class file version 65.0), this version of the Java Runtime only recognizes class file versions up to 61.0"
            )
        )
    }

    var crashAnalyses by remember { mutableStateOf(initialAnalysis) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Crash Doctor & Error Analysis", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("AI Stack Trace Diagnostics & Remediation", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            isAnalyzing = true
                            // Re-run diagnostic on current logs
                            val errorLines = logs.filter { it.contains("Exception", ignoreCase = true) || it.contains("ERROR", ignoreCase = true) }
                            val newReport = CrashReportAnalysis(
                                timestamp = "Live Diagnostic Scan",
                                exceptionType = if (errorLines.isNotEmpty()) "Logged Exception in Console Buffer" else "Clean Buffer - No Fatal Exceptions",
                                culpritModule = if (errorLines.isNotEmpty()) errorLines.last().take(40) else "None Detected",
                                summary = if (errorLines.isNotEmpty()) "Analyzed ${errorLines.size} warning/error messages in console buffer." else "Immediate console buffer contains standard Paper initialization messages.",
                                suggestedFix = "1. Maintain view-distance=6.\n2. Ensure `/crash-reports/` folder is empty via File Manager.",
                                severity = if (errorLines.isNotEmpty()) "MEDIUM" else "LOW",
                                stackTraceSnippet = errorLines.takeLast(3).joinToString("\n")
                            )
                            crashAnalyses = listOf(newReport) + crashAnalyses.take(3)
                            isAnalyzing = false
                        }
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = "Run Scan", tint = IceCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Banner
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BugReport, contentDescription = null, tint = IceCyan, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Automated Crash Intelligence", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                "COLDMC AI parses Java stack traces, watchdog crash-reports, and OOM terminations, providing step-by-step fix recommendations.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            items(crashAnalyses, key = { it.id }) { report ->
                val severityColor = when (report.severity) {
                    "CRITICAL" -> OfflineRed
                    "HIGH" -> StoppingOrange
                    "MEDIUM" -> StartingAmber
                    else -> OnlineGreen
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, severityColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Badge(containerColor = severityColor.copy(alpha = 0.2f), contentColor = severityColor) {
                                Text(report.severity, fontWeight = FontWeight.Bold)
                            }
                            Text(report.timestamp, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(report.exceptionType, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                        Text("Culprit: ${report.culpritModule}", style = MaterialTheme.typography.bodySmall, color = IceCyan)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(report.summary, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

                        if (report.stackTraceSnippet.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Stack Trace Extract:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF070B14))
                                    .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    report.stackTraceSnippet,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFFBAE6FD)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            modifier = Modifier.fillMaxWidth().border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = IceCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("AI Remediation Steps", fontWeight = FontWeight.Bold, color = IceCyan, style = MaterialTheme.typography.labelMedium)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(report.suggestedFix, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
