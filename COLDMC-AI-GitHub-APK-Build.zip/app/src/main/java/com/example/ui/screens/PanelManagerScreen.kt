package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PterodactylPanel
import com.example.ui.components.ConfirmationDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelManagerScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val panels by viewModel.panels.collectAsState()
    val activePanel by viewModel.activePanel.collectAsState()
    val isTestingPanel by viewModel.isTestingPanel.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingPanel by remember { mutableStateOf<PterodactylPanel?>(null) }
    var panelToDelete by remember { mutableStateOf<PterodactylPanel?>(null) }

    // Form inputs for Add/Edit Panel
    var formName by remember { mutableStateOf("") }
    var formUrl by remember { mutableStateOf("") }
    var formUsername by remember { mutableStateOf("") }
    var formPassword by remember { mutableStateOf("") }
    var formApiKey by remember { mutableStateOf("") }
    var showApiKey by remember { mutableStateOf(false) }

    fun openDialog(panel: PterodactylPanel?) {
        editingPanel = panel
        if (panel != null) {
            formName = panel.name
            formUrl = panel.url
            formUsername = panel.username
            formPassword = panel.passwordMasked
            formApiKey = panel.apiKey
        } else {
            formName = "Custom Pterodactyl Panel"
            formUrl = "https://panel.example.com"
            formUsername = ""
            formPassword = ""
            formApiKey = ""
        }
        showAddDialog = true
    }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Multiple Pterodactyl Panels", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Unlimited Hosting Node Management", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { openDialog(null) },
                        modifier = Modifier.testTag("add_panel_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Panel", tint = IceCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { openDialog(null) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add New Panel", fontWeight = FontWeight.Bold) },
                containerColor = IceCyan,
                contentColor = Color.Black,
                modifier = Modifier.testTag("fab_add_panel")
            )
        }

    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Info header card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudQueue, contentDescription = null, tint = IceCyan, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Multi-Provider Panel Architecture",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                "Connect unlimited Pterodactyl panels from any hosting provider. Each panel uses independent credentials and client tokens.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            if (panels.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Panels Configured Yet", color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Tap 'Add New Panel' to connect your first Pterodactyl instance", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else {
                items(panels, key = { it.id }) { panel ->
                    val isActive = panel.id == activePanel?.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, if (isActive) IceCyan else CyberBorder, RoundedCornerShape(14.dp))
                            .clickable { viewModel.selectPanel(panel.id) },
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (panel.isConnected) OnlineGreen.copy(alpha = 0.15f) else OfflineRed.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Dns,
                                            contentDescription = null,
                                            tint = if (panel.isConnected) OnlineGreen else OfflineRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(panel.name, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                                        Text(panel.url, style = MaterialTheme.typography.bodySmall, color = IceCyan)
                                    }
                                }

                                if (isActive) {
                                    Badge(containerColor = IceCyan, contentColor = Color.Black) {
                                        Text("ACTIVE", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Details row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Status: ${panel.status} • Servers: ${panel.serverCount}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (panel.isConnected) OnlineGreen else StartingAmber
                                )
                                Text(
                                    text = if (panel.apiKey.isNotBlank()) "Key: ${panel.apiKey.take(8)}••••" else "No API Key",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.testPanel(panel) },
                                    enabled = !isTestingPanel,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = IceCyan),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, IceCyan.copy(alpha = 0.5f))
                                ) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Test Connection", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { openDialog(panel) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 12.sp)
                                }

                                IconButton(
                                    onClick = { panelToDelete = panel },
                                    modifier = Modifier.testTag("delete_panel_${panel.id}")
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Panel", tint = OfflineRed)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    if (editingPanel == null) "Add New Pterodactyl Panel" else "Edit Panel Connection",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Enter any Pterodactyl panel URL (e.g., https://panel.yourdomain.com). Do NOT use fake or hardcoded URLs.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    OutlinedTextField(
                        value = formName,
                        onValueChange = { formName = it },
                        label = { Text("Panel Name / Label") },
                        placeholder = { Text("e.g. NPCraft Node / Apex Hosting") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_panel_name"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )

                    OutlinedTextField(
                        value = formUrl,
                        onValueChange = { formUrl = it },
                        label = { Text("Panel URL") },
                        placeholder = { Text("https://panel.example.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_panel_url"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )

                    OutlinedTextField(
                        value = formUsername,
                        onValueChange = { formUsername = it },
                        label = { Text("Email / Username (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )

                    OutlinedTextField(
                        value = formApiKey,
                        onValueChange = { formApiKey = it },
                        label = { Text("Pterodactyl Client API Key") },
                        placeholder = { Text("ptlc_xxxxxxxxxxxx...") },
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = TextSecondary
                                )
                            }
                        },
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_panel_apikey"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = IceCyan, unfocusedBorderColor = CyberBorder)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newOrUpdated = (editingPanel ?: PterodactylPanel()).copy(
                            name = formName.ifBlank { "Pterodactyl Panel" },
                            url = formUrl.trim().removeSuffix("/"),
                            username = formUsername.trim(),
                            apiKey = formApiKey.trim()
                        )
                        viewModel.savePanel(newOrUpdated)
                        viewModel.testPanel(newOrUpdated)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = Color.Black),
                    modifier = Modifier.testTag("save_panel_submit_button")
                ) {
                    Text("Save & Connect", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Confirmation
    if (panelToDelete != null) {
        ConfirmationDialog(
            title = "Delete Saved Panel?",
            message = "This will remove '${panelToDelete!!.name}' (${panelToDelete!!.url}) and all associated server records from local storage.",
            confirmText = "Delete Panel",
            isDestructive = true,
            onConfirm = {
                viewModel.deletePanel(panelToDelete!!.id)
                panelToDelete = null
            },
            onDismiss = { panelToDelete = null }
        )
    }
}
