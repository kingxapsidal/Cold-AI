package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLogEntry
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityHistoryScreen(
    viewModel: ColdMcViewModel,
    onBack: () -> Unit
) {
    val auditLogs by viewModel.auditLogs.collectAsState()
    val sdf = remember { SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault()) }

    Scaffold(
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Activity History & Audit Logs", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Immutable Ledger of Operations & AI Actions", style = MaterialTheme.typography.bodySmall, color = IceCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.clearAuditLogs() },
                        modifier = Modifier.testTag("clear_audit_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear History", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Summary Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = IceCyan, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Security Audit Trail", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                "Tracks power dispatches, file edits, AI authorizations, ban actions, and configuration changes.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            if (auditLogs.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("No audit log records recorded yet.", color = TextMuted)
                    }
                }
            } else {
                items(auditLogs, key = { it.id }) { log ->
                    val statusColor = when (log.status) {
                        "SUCCESS" -> OnlineGreen
                        "FAILED" -> OfflineRed
                        else -> StartingAmber
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (log.actor == "COLDMC AI") Icons.Default.AutoAwesome else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = if (log.actor == "COLDMC AI") IceCyan else TextPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(log.actor, fontWeight = FontWeight.Bold, color = if (log.actor == "COLDMC AI") IceCyan else TextPrimary, fontSize = 12.sp)
                                }

                                Text(
                                    text = sdf.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(log.action, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Server: ${log.serverName}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Badge(containerColor = statusColor.copy(alpha = 0.2f), contentColor = statusColor) {
                                    Text(log.status, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (log.details.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
