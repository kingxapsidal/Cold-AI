package com.example.data.minecraft

import com.example.data.model.MinecraftPingResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

object MinecraftPing {

    suspend fun pingServer(host: String, port: Int = 25565, timeoutMs: Int = 3500): MinecraftPingResult =
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.soTimeout = timeoutMs
                socket.connect(InetSocketAddress(host, port), timeoutMs)

                val out = DataOutputStream(socket.getOutputStream())
                val `in` = DataInputStream(socket.getInputStream())

                // 1. Send Handshake Packet (ID 0x00, protocol 767/modern, host, port, nextState=1)
                val handshakeBytes = ByteArrayOutputStream()
                val handshakeData = DataOutputStream(handshakeBytes)
                writeVarInt(handshakeData, 0x00) // Packet ID
                writeVarInt(handshakeData, 767)  // Protocol version (modern 1.21.x fallback)
                writeString(handshakeData, host) // Server host
                handshakeData.writeShort(port)   // Server port
                writeVarInt(handshakeData, 1)    // Next state: 1 (status)

                val handshakePacket = handshakeBytes.toByteArray()
                writeVarInt(out, handshakePacket.size)
                out.write(handshakePacket)

                // 2. Send Status Request Packet (ID 0x00, 0 length data)
                writeVarInt(out, 1)
                writeVarInt(out, 0x00)
                out.flush()

                // 3. Read Status Response Packet
                val packetLength = readVarInt(`in`)
                if (packetLength < 1) {
                    throw IllegalStateException("Empty status response from server")
                }

                val packetId = readVarInt(`in`)
                if (packetId != 0x00) {
                    throw IllegalStateException("Unexpected packet ID: $packetId (expected 0x00)")
                }

                val jsonLength = readVarInt(`in`)
                val jsonBytes = ByteArray(jsonLength)
                `in`.readFully(jsonBytes)
                val jsonString = String(jsonBytes, Charsets.UTF_8)

                val latency = System.currentTimeMillis() - startTime

                // 4. Parse Server Response JSON
                val json = JSONObject(jsonString)
                val versionObj = json.optJSONObject("version")
                val versionName = versionObj?.optString("name", "Unknown") ?: "Unknown"
                val protocol = versionObj?.optInt("protocol", 0) ?: 0

                val playersObj = json.optJSONObject("players")
                val onlinePlayers = playersObj?.optInt("online", 0) ?: 0
                val maxPlayers = playersObj?.optInt("max", 0) ?: 0

                val playerSample = mutableListOf<String>()
                val sampleArray = playersObj?.optJSONArray("sample")
                if (sampleArray != null) {
                    for (i in 0 until sampleArray.length()) {
                        val pObj = sampleArray.optJSONObject(i)
                        val name = pObj?.optString("name")
                        if (!name.isNullOrBlank()) {
                            playerSample.add(name)
                        }
                    }
                }

                // MOTD can be a string or a component object
                val motdRaw = json.opt("description")
                val motdClean = extractCleanMotd(motdRaw)

                MinecraftPingResult(
                    isOnline = true,
                    latencyMs = latency,
                    version = versionName,
                    protocol = protocol,
                    playersOnline = onlinePlayers,
                    playersMax = maxPlayers,
                    motdClean = motdClean,
                    playerSample = playerSample,
                    error = null
                )
            } catch (e: Exception) {
                MinecraftPingResult(
                    isOnline = false,
                    latencyMs = 0,
                    version = "Offline",
                    protocol = 0,
                    playersOnline = 0,
                    playersMax = 0,
                    motdClean = "Cannot connect to server (${e.localizedMessage ?: "Connection refused"})",
                    playerSample = emptyList(),
                    error = e.localizedMessage ?: "Connection failed"
                )
            } finally {
                try {
                    socket?.close()
                } catch (_: Exception) {}
            }
        }

    private fun extractCleanMotd(raw: Any?): String {
        if (raw == null) return "A Minecraft Server"
        if (raw is String) {
            return stripMinecraftFormatting(raw)
        }
        if (raw is JSONObject) {
            val text = raw.optString("text", "")
            val extraArray = raw.optJSONArray("extra")
            val sb = java.lang.StringBuilder(text)
            if (extraArray != null) {
                for (i in 0 until extraArray.length()) {
                    val item = extraArray.opt(i)
                    if (item is JSONObject) {
                        sb.append(item.optString("text", ""))
                    } else if (item is String) {
                        sb.append(item)
                    }
                }
            }
            return stripMinecraftFormatting(sb.toString())
        }
        return raw.toString()
    }

    private fun stripMinecraftFormatting(input: String): String {
        return input.replace(Regex("§[0-9a-fk-orA-FK-OR]"), "").trim()
    }

    @Throws(Exception::class)
    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while (true) {
            if ((v and 0x7F.inv()) == 0) {
                out.writeByte(v)
                return
            }
            out.writeByte((v and 0x7F) or 0x80)
            v = v ushr 7
        }
    }

    @Throws(Exception::class)
    private fun writeString(out: DataOutputStream, string: String) {
        val bytes = string.toByteArray(Charsets.UTF_8)
        writeVarInt(out, bytes.size)
        out.write(bytes)
    }

    @Throws(Exception::class)
    private fun readVarInt(`in`: DataInputStream): Int {
        var numRead = 0
        var result = 0
        var read: Byte
        do {
            read = `in`.readByte()
            val value = (read.toInt() and 0x7F)
            result = result or (value shl (7 * numRead))
            numRead++
            if (numRead > 5) {
                throw RuntimeException("VarInt is too big")
            }
        } while ((read.toInt() and 0x80) != 0)
        return result
    }
}
