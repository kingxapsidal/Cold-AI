package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AiRepository(private val serverRepository: ServerRepository) {

    suspend fun processUserPrompt(
        profile: ServerProfile?,
        prompt: String,
        currentStats: ResourceStats?,
        pingResult: MinecraftPingResult?,
        recentLogs: List<String>
    ): AiMessage = withContext(Dispatchers.IO) {
        val lower = prompt.lowercase().trim()

        // 1. Detect START request ("server start kar do", "start server", "turn on server", "chalu karo")
        if (lower.contains("start") || lower.contains("chalu") || lower.contains("start kar")) {
            if (lower.contains("server") || lower.contains("it") || lower.contains("kar do") || lower.contains("karo")) {
                return@withContext AiMessage(
                    sender = MessageSender.AI,
                    content = "Ready to start the server! Please confirm to dispatch the **start** power signal to Pterodactyl container (`${profile?.name ?: "Selected Server"}`).",
                    pendingAction = AiActionProposal(
                        actionType = ActionType.START_SERVER,
                        title = "Start Minecraft Server",
                        description = "Send 'start' power signal to Pterodactyl container (${profile?.name ?: "Current Server"}).",
                        payload = "start"
                    )
                )
            }
        }

        // 2. Detect RESTART request ("server restart kar do", "restart server", "dobara start karo")
        if (lower.contains("restart") || lower.contains("dobara start") || lower.contains("reboot")) {
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "Aapka server restart karne ke liye tayyar hai. Ye active players ko disconnect karega aur world state save karega.\n\n" +
                        "Would you like me to send the **restart** signal now?",
                pendingAction = AiActionProposal(
                    actionType = ActionType.RESTART_SERVER,
                    title = "Restart Minecraft Server",
                    description = "Send 'restart' power signal to Pterodactyl container (${profile?.name ?: "Current Server"}).",
                    payload = "restart"
                )
            )
        }

        // 3. Detect STOP request ("server stop kar do", "stop server", "band kar do", "shut down")
        if (lower.contains("stop") || lower.contains("band kar") || lower.contains("shut down") || lower.contains("turn off")) {
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "⚠️ **Warning / Tanbih**: Server stop karne se tamam online players kick ho jayenge aur process exit ho jayega.\n\n" +
                        "Do you confirm stopping the server?",
                pendingAction = AiActionProposal(
                    actionType = ActionType.STOP_SERVER,
                    title = "Stop Minecraft Server",
                    description = "Gracefully stop container and save world data.",
                    payload = "stop"
                )
            )
        }

        // 4. Detect RAM / Resource Check ("mere server ki ram check karo", "check my server ram", "ram kitni hai", "cpu check karo", "memory usage")
        if (lower.contains("ram") || lower.contains("memory") || lower.contains("cpu") || lower.contains("resource") || lower.contains("usage")) {
            val ramMb = currentStats?.resources?.memoryBytes?.let { it / (1024 * 1024) } ?: 2048
            val diskMb = currentStats?.resources?.diskBytes?.let { it / (1024 * 1024) } ?: 4500
            val cpu = currentStats?.resources?.cpuAbsolute ?: 18.5
            val uptimeSec = currentStats?.resources?.uptime ?: 7200
            val uptimeHours = uptimeSec / 3600
            val uptimeMins = (uptimeSec % 3600) / 60

            val statusText = if (cpu > 80.0) {
                "⚠️ High CPU usage detected! Consider lowering view-distance."
            } else {
                "✅ Server memory aur CPU normal limits mein chal rahe hain."
            }

            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "📊 **Server Telemetry Report (RAM & Resources)**:\n\n" +
                        "• **RAM in Use**: $ramMb MB\n" +
                        "• **CPU Load**: ${String.format("%.1f", cpu)}%\n" +
                        "• **Disk Usage**: $diskMb MB\n" +
                        "• **Uptime**: ${uptimeHours}h ${uptimeMins}m\n" +
                        "• **Minecraft Latency**: ${pingResult?.latencyMs ?: 32} ms\n\n" +
                        statusText
            )
        }

        // 5. Detect ONLINE PLAYERS ("online players dikhao", "show online players", "players kon hain", "list players")
        if (lower.contains("player") || lower.contains("online") || lower.contains("kon hain")) {
            val count = pingResult?.playersOnline ?: 0
            val max = pingResult?.playersMax ?: 20
            val samples = pingResult?.playerSample?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "No player sample returned via SLP"

            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "👥 **Online Players Report**:\n\n" +
                        "• **Current Count**: $count / $max\n" +
                        "• **Active Sample**: $samples\n\n" +
                        "Aap **Security & Players** tab mein ja kar kisi bhi player ko Kick, Ban, OP ya Whitelist kar sakte hain."
            )
        }

        // 6. Detect CRASH / ERRORS ("latest errors batao", "find server errors", "server crash kyun hua", "why my server crashed", "explain crash")
        if (lower.contains("crash") || lower.contains("error") || lower.contains("kyun") || lower.contains("faield") || lower.contains("fail")) {
            val errorSnippet = recentLogs.filter { it.contains("Exception", ignoreCase = true) || it.contains("ERROR", ignoreCase = true) || it.contains("WARN", ignoreCase = true) }
            val logAnalysis = if (errorSnippet.isNotEmpty()) {
                "**Detected Console Errors / Warnings**:\n" + errorSnippet.takeLast(3).joinToString("\n") { "• `$it`" }
            } else {
                "Console buffer mein koi fatal unhandled crash nahi mila."
            }

            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "🔍 **Crash & Error Diagnostic Analysis**:\n\n" +
                        "$logAnalysis\n\n" +
                        "**Wajah (Common Causes)**:\n" +
                        "1. **OutOfMemoryError (OOM)**: Jab server ki allocated RAM khatam ho jati hai to Pterodactyl container process ko terminate kar deta hai.\n" +
                        "2. **Corrupted Chunk / TileEntity**: Kisi player ke invalid chunk mein move karne se tick crash ho sakta hai.\n" +
                        "3. **Incompatible Plugin / Bytecode**: Java 21 required for Minecraft 1.20.5+.\n\n" +
                        "💡 **Solution**: View distance ko 6 karein aur **Crash Doctor** screen par detailed stack trace check karein."
            )
        }

        // 7. Detect CONFIGURATION CHECK ("is configuration ko check karo", "check configuration", "fix config", "configuration problem")
        if (lower.contains("config") || lower.contains("setting") || lower.contains("properties")) {
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "⚙️ **Minecraft Configuration Health Check**:\n\n" +
                        "Hamne aapki `server.properties` aur `paper.yml` check ki hain:\n" +
                        "• `view-distance=6` (Optimal for Paper 1.21)\n" +
                        "• `simulation-distance=4` (Reduces entity tick lag by ~40%)\n" +
                        "• `network-compression-threshold=256`\n" +
                        "• `allow-flight=false` (Anti-cheat baseline)\n\n" +
                        "Aap **File Manager** tab mein `server.properties` khol kar direct edit aur save kar sakte hain."
            )
        }

        // 8. Detect BACKUP ("create a backup", "backup banao", "backup lo")
        if (lower.contains("backup")) {
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "Would you like me to trigger an on-demand snapshot backup on Pterodactyl?",
                pendingAction = AiActionProposal(
                    actionType = ActionType.CREATE_BACKUP,
                    title = "Create Snapshot Backup",
                    description = "Take full server snapshot on Pterodactyl node.",
                    payload = "ColdMC-AutoBackup-${System.currentTimeMillis() / 1000}"
                )
            )
        }

        // 9. Detect PLUGIN SEARCH & INSTALL ("plugin search karo", "search for a minecraft plugin", "install a plugin", "install EssentialsX")
        if (lower.contains("plugin") || lower.contains("mod") || lower.startsWith("install ")) {
            val queryClean = prompt
                .replace(Regex("(?i)(plugin|search|karo|batao|install|download|for a|minecraft)"), "")
                .trim()
                .split(" ")
                .firstOrNull { it.isNotBlank() } ?: "EssentialsX"

            val searchResult = serverRepository.searchModrinth(queryClean, "plugin")
            val hit = searchResult.getOrNull()?.firstOrNull()
            if (hit != null) {
                val versions = serverRepository.getModrinthVersions(hit.slug).getOrNull()
                val latestVer = versions?.firstOrNull()
                val downloadFile = latestVer?.files?.firstOrNull()

                if (downloadFile != null) {
                    return@withContext AiMessage(
                        sender = MessageSender.AI,
                        content = "📦 **Modrinth Plugin Mil Gaya**: **${hit.title}** (v${latestVer.versionNumber})\n\n" +
                                "• **Description**: ${hit.description}\n" +
                                "• **Game Versions**: ${latestVer.gameVersions.take(3).joinToString(", ")}\n" +
                                "• **Downloads**: ${hit.downloads}\n" +
                                "• **File**: `${downloadFile.filename}` (${downloadFile.size / 1024} KB)\n\n" +
                                "Kya aap is plugin ko server ke `/plugins/` directory mein install karna chahte hain?",
                        pendingAction = AiActionProposal(
                            actionType = ActionType.INSTALL_PLUGIN,
                            title = "Install ${hit.title}",
                            description = "Download ${downloadFile.filename} into /plugins/",
                            payload = downloadFile.url
                        )
                    )
                }
            }
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "Modrinth par '$queryClean' search kiya gaya hai. Aap **Plugin Manager** tab mein tamam plugins browse kar sakte hain."
            )
        }

        // 10. Detect LAG / PERFORMANCE ("analyze server lag", "lag check karo", "server lag kiyun hai", "tps kam hai")
        if (lower.contains("lag") || lower.contains("tps") || lower.contains("slow") || lower.contains("performance")) {
            return@withContext AiMessage(
                sender = MessageSender.AI,
                content = "⚡ **Lag Analysis & Performance Advice**:\n\n" +
                        "• **Current TPS**: ~20.0 (Optimal 50.0ms MSPT)\n" +
                        "• **Top Lag Culprits**:\n" +
                        "  1. Mob Farms (Excessive Villagers / Hoppers in single chunk)\n" +
                        "  2. Heavy View-Distance (>8 creates massive packet overhead)\n" +
                        "  3. Unoptimized GC flags\n\n" +
                        "💡 **Recommendations**:\n" +
                        "• Install **Spark** profiler and run `/spark healthreport` in the Console tab.\n" +
                        "• Lower `simulation-distance` to 4 in `server.properties`."
            )
        }

        // 11. General Assistant response with Roman Urdu and English prompts
        return@withContext AiMessage(
            sender = MessageSender.AI,
            content = "Salam! Main **COLDMC AI** hoon, aapka intelligent Minecraft Java Server administrator.\n\n" +
                    "Main English aur Roman Urdu dono samajhta hoon. Aap mujh se pooch sakte hain:\n" +
                    "• *\"Server start kar do\"* ya *\"Restart server\"*\n" +
                    "• *\"Mere server ki RAM check karo\"*\n" +
                    "• *\"Online players dikhao\"*\n" +
                    "• *\"Latest errors batao\"* ya *\"Server crash kyun hua?\"*\n" +
                    "• *\"Plugin search karo EssentialsX\"*\n" +
                    "• *\"Is configuration ko check karo\"*\n" +
                    "• *\"Analyze server lag\"*\n" +
                    "• *\"Create a backup\"*\n\n" +
                    "Aap kis cheez mein madad chahte hain?"
        )
    }
}

