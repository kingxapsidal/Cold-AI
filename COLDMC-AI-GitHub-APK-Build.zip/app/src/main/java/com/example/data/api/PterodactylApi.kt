package com.example.data.api

import com.example.data.model.*
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface PterodactylApi {

    @GET("api/client")
    suspend fun getServers(): Response<PteroListResponse<ServerAttributes>>

    @GET("api/client/account")
    suspend fun getAccount(): Response<ResponseBody>

    @GET("api/client/servers/{server}")
    suspend fun getServerDetails(
        @Path("server") serverId: String
    ): Response<PteroDataObject<ServerAttributes>>

    @GET("api/client/servers/{server}/resources")
    suspend fun getServerResources(
        @Path("server") serverId: String
    ): Response<ResourceStatsResponse>

    @POST("api/client/servers/{server}/power")
    suspend fun sendPowerSignal(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest
    ): Response<Unit>

    @POST("api/client/servers/{server}/command")
    suspend fun sendCommand(
        @Path("server") serverId: String,
        @Body command: CommandRequest
    ): Response<Unit>

    @GET("api/client/servers/{server}/files/list")
    suspend fun listFiles(
        @Path("server") serverId: String,
        @Query("directory") directory: String = "/"
    ): Response<PteroListResponse<FileAttributes>>

    @GET("api/client/servers/{server}/files/contents")
    suspend fun getFileContents(
        @Path("server") serverId: String,
        @Query("file") filePath: String
    ): Response<ResponseBody>

    @POST("api/client/servers/{server}/files/write")
    suspend fun writeFile(
        @Path("server") serverId: String,
        @Query("file") filePath: String,
        @Body content: RequestBody
    ): Response<Unit>

    @POST("api/client/servers/{server}/files/delete")
    suspend fun deleteFiles(
        @Path("server") serverId: String,
        @Body deleteRequest: DeleteFilesRequest
    ): Response<Unit>

    @POST("api/client/servers/{server}/files/pull")
    suspend fun pullFile(
        @Path("server") serverId: String,
        @Body pullRequest: PullFileRequest
    ): Response<Unit>

    @GET("api/client/servers/{server}/backups")
    suspend fun listBackups(
        @Path("server") serverId: String
    ): Response<PteroListResponse<BackupAttributes>>

    @POST("api/client/servers/{server}/backups")
    suspend fun createBackup(
        @Path("server") serverId: String,
        @Body backupRequest: CreateBackupRequest
    ): Response<PteroDataObject<BackupAttributes>>
}
