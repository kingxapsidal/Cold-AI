package com.example.data.api

import com.example.data.model.ModrinthSearchResponse
import com.example.data.model.ModrinthVersion
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ModrinthApi {

    @GET("search")
    suspend fun searchProjects(
        @Query("query") query: String,
        @Query("facets") facets: String = "[[\"project_type:plugin\"]]",
        @Query("limit") limit: Int = 15
    ): Response<ModrinthSearchResponse>

    @GET("project/{id}/version")
    suspend fun getProjectVersions(
        @Path("id") projectIdOrSlug: String
    ): Response<List<ModrinthVersion>>
}
