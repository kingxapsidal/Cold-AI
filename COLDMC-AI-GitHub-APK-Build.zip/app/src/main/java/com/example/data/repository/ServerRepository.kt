package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.api.FastApiBackendApi
import com.example.data.api.ModrinthApi
import com.example.data.api.PterodactylApi
import com.example.data.minecraft.MinecraftPing
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class ServerRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("coldmc_server_profiles", Context.MODE_PRIVATE)

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val profileListAdapter = moshi.adapter<List<ServerProfile>>(
        Types.newParameterizedType(List::class.java, ServerProfile::class.java)
    )

    private val _profiles = MutableStateFlow<List<ServerProfile>>(emptyList())
    val profiles: StateFlow<List<ServerProfile>> = _profiles.asStateFlow()

    private val _activeProfile = MutableStateFlow<ServerProfile?>(null)
    val activeProfile: StateFlow<ServerProfile?> = _activeProfile.asStateFlow()

    private val _availableServers = MutableStateFlow<List<ServerAttributes>>(emptyList())
    val availableServers: StateFlow<List<ServerAttributes>> = _availableServers.asStateFlow()

    // Multi-Panel Management State
    private val _panels = MutableStateFlow<List<PterodactylPanel>>(emptyList())
    val panels: StateFlow<List<PterodactylPanel>> = _panels.asStateFlow()

    private val _activePanel = MutableStateFlow<PterodactylPanel?>(null)
    val activePanel: StateFlow<PterodactylPanel?> = _activePanel.asStateFlow()

    // Multi-Server Management State
    private val _servers = MutableStateFlow<List<ManagedServer>>(emptyList())
    val servers: StateFlow<List<ManagedServer>> = _servers.asStateFlow()

    private val _activeServer = MutableStateFlow<ManagedServer?>(null)
    val activeServer: StateFlow<ManagedServer?> = _activeServer.asStateFlow()

    // Audit Log & Activity History
    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(
        listOf(
            AuditLogEntry(
                timestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                actor = "COLDMC AI",
                action = "Health Check & SLP Ping",
                serverName = "Survival Server",
                status = "SUCCESS",
                details = "Latency 34ms, 12 online players"
            ),
            AuditLogEntry(
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 2,
                actor = "Operator",
                action = "Saved Configuration",
                serverName = "Survival Server",
                status = "SUCCESS",
                details = "Updated server.properties (view-distance: 6)"
            )
        )
    )
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    // Discord Integration Config
    private val _discordConfig = MutableStateFlow(DiscordConfig())
    val discordConfig: StateFlow<DiscordConfig> = _discordConfig.asStateFlow()

    private val modrinthApi: ModrinthApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.modrinth.com/v2/")
            .client(
                OkHttpClient.Builder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .build()
            )
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(ModrinthApi::class.java)
    }

    init {
        loadProfiles()
    }

    private fun loadProfiles() {
        val json = prefs.getString("saved_profiles", null)
        val loaded = if (!json.isNullOrBlank()) {
            try {
                profileListAdapter.fromJson(json) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }

        if (loaded.isNotEmpty()) {
            _profiles.value = loaded
            val activeId = prefs.getString("active_profile_id", null)
            _activeProfile.value = loaded.find { it.id == activeId } ?: loaded.first()
        } else {
            // Default sample profile targeting the user's specified panel
            val initial = ServerProfile(
                name = "NPCraft Panel",
                panelUrl = "https://panel.npcraft.bond",
                apiKey = "",
                panelUser = "admin",
                serverIdentifier = "",
                minecraftHost = "panel.npcraft.bond",
                minecraftPort = 25565
            )
            _profiles.value = listOf(initial)
            _activeProfile.value = initial
            saveProfilesInternal(listOf(initial), initial.id)
        }
    }

    private fun saveProfilesInternal(list: List<ServerProfile>, activeId: String?) {
        val json = profileListAdapter.toJson(list)
        prefs.edit()
            .putString("saved_profiles", json)
            .putString("active_profile_id", activeId)
            .apply()
    }

    fun saveProfile(profile: ServerProfile) {
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            current[index] = profile
        } else {
            current.add(profile)
        }
        _profiles.value = current
        _activeProfile.value = profile
        saveProfilesInternal(current, profile.id)
    }

    fun selectActiveProfile(profileId: String) {
        val found = _profiles.value.find { it.id == profileId }
        if (found != null) {
            _activeProfile.value = found
            prefs.edit().putString("active_profile_id", profileId).apply()
        }
    }

    fun removeProfile(profileId: String) {
        val current = _profiles.value.filter { it.id != profileId }
        _profiles.value = current
        val nextActive = current.firstOrNull()
        _activeProfile.value = nextActive
        saveProfilesInternal(current, nextActive?.id)
    }

    private fun createPterodactylClient(baseUrl: String, apiKey: String): PterodactylApi {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $apiKey")
                    .addHeader("Accept", "application/json")
                    .addHeader("Content-Type", "application/json")
                    .build()
                chain.proceed(request)
            }
            .build()

        return Retrofit.Builder()
            .baseUrl(cleanUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(PterodactylApi::class.java)
    }

    private fun createFastApiClient(baseUrl: String): FastApiBackendApi {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl(cleanUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FastApiBackendApi::class.java)
    }

    suspend fun testConnection(profile: ServerProfile): Result<List<ServerAttributes>> =
        withContext(Dispatchers.IO) {
            try {
                if (profile.isFastApiGatewayMode) {
                    val fastApi = createFastApiClient(profile.fastApiBaseUrl)
                    val resp = fastApi.getServers()
                    if (resp.isSuccessful && resp.body() != null) {
                        val servers = resp.body()!!
                        _availableServers.value = servers
                        Result.success(servers)
                    } else {
                        Result.failure(Exception("Gateway error: HTTP ${resp.code()} ${resp.message()}"))
                    }
                } else {
                    if (profile.apiKey.isBlank()) {
                        return@withContext Result.failure(Exception("Client API Key is required to connect to Pterodactyl"))
                    }
                    val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                    val resp = client.getServers()
                    if (resp.isSuccessful && resp.body() != null) {
                        val servers = resp.body()!!.data.map { it.attributes }
                        _availableServers.value = servers
                        Result.success(servers)
                    } else {
                        val errorBody = resp.errorBody()?.string() ?: ""
                        val msg = if (resp.code() == 401 || resp.code() == 403) {
                            "Authentication failed. Please verify your Pterodactyl Client API Key."
                        } else {
                            "Panel responded with HTTP ${resp.code()}: $errorBody"
                        }
                        Result.failure(Exception(msg))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun fetchServerResources(profile: ServerProfile): Result<ResourceStats> =
        withContext(Dispatchers.IO) {
            try {
                if (profile.serverIdentifier.isBlank()) {
                    return@withContext Result.failure(Exception("No server identifier specified"))
                }
                if (profile.isFastApiGatewayMode) {
                    val fastApi = createFastApiClient(profile.fastApiBaseUrl)
                    val resp = fastApi.getServerStats(profile.serverIdentifier)
                    if (resp.isSuccessful && resp.body() != null) {
                        Result.success(resp.body()!!)
                    } else {
                        Result.failure(Exception("Failed to fetch stats: ${resp.code()}"))
                    }
                } else {
                    val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                    val resp = client.getServerResources(profile.serverIdentifier)
                    if (resp.isSuccessful && resp.body() != null) {
                        Result.success(resp.body()!!.attributes)
                    } else {
                        Result.failure(Exception("HTTP ${resp.code()}: ${resp.message()}"))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun sendPowerSignal(profile: ServerProfile, signal: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                if (profile.isFastApiGatewayMode) {
                    val fastApi = createFastApiClient(profile.fastApiBaseUrl)
                    val resp = fastApi.sendPower(profile.serverIdentifier, PowerSignalRequest(signal))
                    if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Power error ${resp.code()}"))
                } else {
                    val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                    val resp = client.sendPowerSignal(profile.serverIdentifier, PowerSignalRequest(signal))
                    if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Power error ${resp.code()}: ${resp.message()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun sendCommand(profile: ServerProfile, command: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                if (profile.isFastApiGatewayMode) {
                    val fastApi = createFastApiClient(profile.fastApiBaseUrl)
                    val resp = fastApi.sendCommand(profile.serverIdentifier, CommandRequest(command))
                    if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Command error ${resp.code()}"))
                } else {
                    val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                    val resp = client.sendCommand(profile.serverIdentifier, CommandRequest(command))
                    if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Command error ${resp.code()}: ${resp.message()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun listFiles(profile: ServerProfile, directory: String = "/"): Result<List<FileAttributes>> =
        withContext(Dispatchers.IO) {
            try {
                if (profile.isFastApiGatewayMode) {
                    val fastApi = createFastApiClient(profile.fastApiBaseUrl)
                    val resp = fastApi.listFiles(profile.serverIdentifier, directory)
                    if (resp.isSuccessful && resp.body() != null) Result.success(resp.body()!!) else Result.failure(Exception("File error ${resp.code()}"))
                } else {
                    val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                    val resp = client.listFiles(profile.serverIdentifier, directory)
                    if (resp.isSuccessful && resp.body() != null) {
                        Result.success(resp.body()!!.data.map { it.attributes })
                    } else {
                        Result.failure(Exception("File error ${resp.code()}: ${resp.message()}"))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getFileContent(profile: ServerProfile, filePath: String): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val resp = client.getFileContents(profile.serverIdentifier, filePath)
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!.string())
                } else {
                    Result.failure(Exception("Failed to read file: HTTP ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun saveFileContent(profile: ServerProfile, filePath: String, content: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val body = content.toRequestBody("text/plain".toMediaType())
                val resp = client.writeFile(profile.serverIdentifier, filePath, body)
                if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Failed to save: ${resp.code()}"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun deleteFile(profile: ServerProfile, root: String, filename: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val resp = client.deleteFiles(profile.serverIdentifier, DeleteFilesRequest(root, listOf(filename)))
                if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Failed to delete: ${resp.code()}"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun installPluginFromUrl(profile: ServerProfile, downloadUrl: String, destinationFolder: String = "/plugins"): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val resp = client.pullFile(profile.serverIdentifier, PullFileRequest(url = downloadUrl, directory = destinationFolder))
                if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception("Download failed: HTTP ${resp.code()}"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun listBackups(profile: ServerProfile): Result<List<BackupAttributes>> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val resp = client.listBackups(profile.serverIdentifier)
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!.data.map { it.attributes })
                } else {
                    Result.failure(Exception("Backup error ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createBackup(profile: ServerProfile, backupName: String): Result<BackupAttributes> =
        withContext(Dispatchers.IO) {
            try {
                val client = createPterodactylClient(profile.panelUrl, profile.apiKey)
                val resp = client.createBackup(profile.serverIdentifier, CreateBackupRequest(name = backupName))
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!.attributes)
                } else {
                    Result.failure(Exception("Backup creation failed ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun pingMinecraftServer(host: String, port: Int): MinecraftPingResult {
        return MinecraftPing.pingServer(host, port)
    }

    suspend fun searchModrinth(query: String, projectType: String = "plugin"): Result<List<ModrinthHit>> =
        withContext(Dispatchers.IO) {
            try {
                val facet = "[[\"project_type:$projectType\"]]"
                val resp = modrinthApi.searchProjects(query = query, facets = facet, limit = 20)
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!.hits)
                } else {
                    Result.failure(Exception("Modrinth search failed: ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getModrinthVersions(projectSlugOrId: String): Result<List<ModrinthVersion>> =
        withContext(Dispatchers.IO) {
            try {
                val resp = modrinthApi.getProjectVersions(projectSlugOrId)
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!)
                } else {
                    Result.failure(Exception("Failed to get versions: ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }


    // --- Multi-Panel CRUD Operations ---

    fun addOrUpdatePanel(panel: PterodactylPanel) {
        val current = _panels.value.toMutableList()
        val index = current.indexOfFirst { it.id == panel.id }
        if (index >= 0) {
            current[index] = panel
        } else {
            current.add(panel)
        }
        _panels.value = current
        if (_activePanel.value == null || _activePanel.value?.id == panel.id) {
            _activePanel.value = panel
        }
        logAudit("Operator", "Updated Panel: ${panel.name}", panel.name, "SUCCESS", panel.url)
    }

    fun deletePanel(panelId: String) {
        val panel = _panels.value.find { it.id == panelId }
        val current = _panels.value.filter { it.id != panelId }
        _panels.value = current
        if (_activePanel.value?.id == panelId) {
            _activePanel.value = current.firstOrNull()
        }
        // Also remove or unlink servers belonging to this panel
        _servers.value = _servers.value.filter { it.panelId != panelId }
        logAudit("Operator", "Deleted Panel: ${panel?.name ?: panelId}", "System", "SUCCESS", "Removed credentials")
    }

    fun selectActivePanel(panelId: String) {
        val found = _panels.value.find { it.id == panelId }
        if (found != null) {
            _activePanel.value = found
        }
    }

    suspend fun testPanelConnection(panel: PterodactylPanel): Result<List<ServerAttributes>> = withContext(Dispatchers.IO) {
        val tempProfile = ServerProfile(
            name = panel.name,
            panelUrl = panel.url,
            apiKey = panel.apiKey,
            panelUser = panel.username
        )
        val res = testConnection(tempProfile)
        res.fold(
            onSuccess = { list ->
                val updated = panel.copy(
                    isConnected = true,
                    status = "Connected",
                    lastTested = System.currentTimeMillis(),
                    serverCount = list.size
                )
                addOrUpdatePanel(updated)
                // Auto populate servers for this panel if none exist
                list.forEach { srv ->
                    val managed = ManagedServer(
                        id = "${panel.id}-${srv.identifier}",
                        panelId = panel.id,
                        panelName = panel.name,
                        identifier = srv.identifier,
                        name = srv.name,
                        customDisplayName = srv.name,
                        node = srv.node,
                        memoryLimitMb = srv.limits.memory,
                        diskLimitMb = srv.limits.disk,
                        cpuLimitPercent = srv.limits.cpu,
                        status = srv.status ?: "running"
                    )
                    addOrUpdateServer(managed)
                }
                logAudit("Operator", "Tested Connection: ${panel.name}", panel.name, "SUCCESS", "Retrieved ${list.size} server(s)")
                Result.success(list)
            },
            onFailure = { err ->
                val updated = panel.copy(
                    isConnected = false,
                    status = "Error: ${err.message?.take(30)}",
                    lastTested = System.currentTimeMillis()
                )
                addOrUpdatePanel(updated)
                logAudit("Operator", "Failed Connection: ${panel.name}", panel.name, "FAILED", err.localizedMessage ?: "Auth failed")
                Result.failure(err)
            }
        )
    }

    // --- Multi-Server CRUD Operations ---
    fun addOrUpdateServer(server: ManagedServer) {
        val current = _servers.value.toMutableList()
        val index = current.indexOfFirst { it.id == server.id }
        if (index >= 0) {
            current[index] = server
        } else {
            current.add(server)
        }
        _servers.value = current
        if (_activeServer.value == null || _activeServer.value?.id == server.id) {
            selectActiveServer(server.id)
        }
    }

    fun deleteServer(serverId: String) {
        val current = _servers.value.filter { it.id != serverId }
        _servers.value = current
        if (_activeServer.value?.id == serverId) {
            current.firstOrNull()?.let { selectActiveServer(it.id) }
        }
        logAudit("Operator", "Removed Server", serverId, "SUCCESS", "Server removed from management")
    }

    fun selectActiveServer(serverId: String) {
        val server = _servers.value.find { it.id == serverId } ?: return
        _activeServer.value = server

        val panel = _panels.value.find { it.id == server.panelId }
        val updatedProfile = ServerProfile(
            id = server.id,
            name = server.customDisplayName.ifBlank { server.name },
            panelUrl = panel?.url ?: "https://panel.npcraft.bond",
            apiKey = panel?.apiKey ?: "",
            panelUser = panel?.username ?: "",
            serverIdentifier = server.identifier,
            minecraftHost = server.minecraftHost,
            minecraftPort = server.minecraftPort
        )
        _activeProfile.value = updatedProfile
    }

    // --- Audit Logging ---
    fun logAudit(actor: String, action: String, serverName: String, status: String, details: String) {
        val entry = AuditLogEntry(
            timestamp = System.currentTimeMillis(),
            actor = actor,
            action = action,
            serverName = serverName,
            status = status,
            details = details
        )
        _auditLogs.value = listOf(entry) + _auditLogs.value.take(49)
    }

    fun clearAuditLogs() {
        _auditLogs.value = emptyList()
    }

    // --- Discord Integration ---
    fun saveDiscordConfig(config: DiscordConfig) {
        _discordConfig.value = config
        logAudit("Operator", "Configured Discord Integration", "Discord", "SUCCESS", "Webhook updated")
    }

    suspend fun sendDiscordWebhookTest(config: DiscordConfig): Result<Boolean> = withContext(Dispatchers.IO) {
        if (config.webhookUrl.isBlank()) {
            return@withContext Result.failure(Exception("Webhook URL is empty"))
        }
        try {
            val jsonPayload = """
                {
                    "username": "COLDMC AI Guardian",
                    "avatar_url": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/diamond.png",
                    "embeds": [{
                        "title": "❄️ COLDMC AI — Integration Active",
                        "description": "Discord notifications successfully connected to your Minecraft operations hub.",
                        "color": 65535,
                        "fields": [
                            {"name": "Status", "value": "🟢 Connected", "inline": true},
                            {"name": "Server", "value": "${_activeServer.value?.customDisplayName ?: "Minecraft Server"}", "inline": true}
                        ],
                        "footer": {"text": "COLDMC AI • Autonomous Minecraft Java Server Management"}
                    }]
                }
            """.trimIndent()

            val body = jsonPayload.toRequestBody("application/json".toMediaType())
            val request = okhttp3.Request.Builder()
                .url(config.webhookUrl)
                .post(body)
                .build()

            val okHttpClient = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).build()
            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful || response.code == 204) {
                logAudit("System", "Discord Test Webhook", "Discord", "SUCCESS", "Dispatched to channel")
                Result.success(true)
            } else {
                Result.failure(Exception("Discord rejected request: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Mod Discovery (Forge, Fabric, NeoForge) ---
    suspend fun searchModrinthMods(query: String, loader: String = "fabric"): Result<List<ModrinthHit>> =
        withContext(Dispatchers.IO) {
            try {
                val facets = if (loader.isNotBlank()) {
                    "[[\"project_type:mod\"],[\"categories:$loader\"]]"
                } else {
                    "[[\"project_type:mod\"]]"
                }
                val resp = modrinthApi.searchProjects(query = query, facets = facets, limit = 20)
                if (resp.isSuccessful && resp.body() != null) {
                    Result.success(resp.body()!!.hits)
                } else {
                    Result.failure(Exception("Mod search failed: ${resp.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}

