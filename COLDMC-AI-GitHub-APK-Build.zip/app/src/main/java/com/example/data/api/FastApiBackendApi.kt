package com.example.data.api

import com.example.data.model.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface FastApiBackendApi {

    @GET("api/health")
    suspend fun checkHealth(): Response<Map<String, Any>>

    @GET("api/servers")
    suspend fun getServers(): Response<List<ServerAttributes>>

    @GET("api/servers/{id}/stats")
    suspend fun getServerStats(
        @Path("id") serverId: String
    ): Response<ResourceStats>

    @POST("api/servers/{id}/power")
    suspend fun sendPower(
        @Path("id") serverId: String,
        @Body signal: PowerSignalRequest
    ): Response<Map<String, String>>

    @POST("api/servers/{id}/command")
    suspend fun sendCommand(
        @Path("id") serverId: String,
        @Body command: CommandRequest
    ): Response<Map<String, String>>

    @GET("api/servers/{id}/files")
    suspend fun listFiles(
        @Path("id") serverId: String,
        @Query("directory") directory: String = "/"
    ): Response<List<FileAttributes>>

    @GET("api/anti-cheat/violations")
    suspend fun getViolations(): Response<List<AntiCheatViolation>>
}
