package com.example.data.repository

import com.example.data.model.AntiCheatViolation
import com.example.data.model.PlayerInfo
import com.example.data.model.ViolationSeverity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ModerationRepository {

    private val _players = MutableStateFlow<List<PlayerInfo>>(
        listOf(
            PlayerInfo(username = "ColdAdmin", uuid = "e578a1bc-1234-4567-89ab-cdef01234567", isOnline = true, isOp = true, isWhitelisted = true, ping = 24),
            PlayerInfo(username = "FrostKnight99", uuid = "b234c567-2345-6789-01bc-def012345678", isOnline = true, isOp = false, isWhitelisted = true, ping = 48),
            PlayerInfo(username = "ViperX_PvP", uuid = "c345d678-3456-7890-12cd-ef0123456789", isOnline = true, isOp = false, isWhitelisted = true, ping = 112),
            PlayerInfo(username = "GlitchBoi", uuid = "d456e789-4567-8901-23de-f01234567890", isOnline = false, isOp = false, isWhitelisted = false, isBanned = true, ping = 0)
        )
    )
    val players: StateFlow<List<PlayerInfo>> = _players.asStateFlow()

    private val _violations = MutableStateFlow<List<AntiCheatViolation>>(
        listOf(
            AntiCheatViolation(
                player = "ViperX_PvP",
                checkName = "Combat: Reach (3.38 blocks)",
                category = "Combat",
                severity = ViolationSeverity.HIGH,
                ping = 112,
                details = "Player hit target 3.38m away (max threshold 3.00m + 0.1m ping allowance)."
            ),
            AntiCheatViolation(
                player = "GlitchBoi",
                checkName = "Movement: Speed B (Unusual Delta Y)",
                category = "Movement",
                severity = ViolationSeverity.CRITICAL,
                ping = 85,
                details = "Ascending velocity violated vanilla physics trajectory (potential fly/glide hack)."
            ),
            AntiCheatViolation(
                player = "ShadowCrafter",
                checkName = "Chat: Spam Frequency (>4 msg/sec)",
                category = "Chat",
                severity = ViolationSeverity.LOW,
                ping = 35,
                details = "Sent repetitive server IP address text repeatedly in global chat.",
                status = "Auto-Muted (5 min)"
            )
        )
    )
    val violations: StateFlow<List<AntiCheatViolation>> = _violations.asStateFlow()

    private val _autoMuteEnabled = MutableStateFlow(true)
    val autoMuteEnabled: StateFlow<Boolean> = _autoMuteEnabled.asStateFlow()

    fun toggleAutoMute(enabled: Boolean) {
        _autoMuteEnabled.value = enabled
    }

    fun dismissViolation(violationId: String) {
        _violations.value = _violations.value.filter { it.id != violationId }
    }

    fun toggleOp(username: String) {
        _players.value = _players.value.map {
            if (it.username.equals(username, ignoreCase = true)) it.copy(isOp = !it.isOp) else it
        }
    }

    fun toggleWhitelist(username: String) {
        _players.value = _players.value.map {
            if (it.username.equals(username, ignoreCase = true)) it.copy(isWhitelisted = !it.isWhitelisted) else it
        }
    }

    fun banPlayer(username: String) {
        _players.value = _players.value.map {
            if (it.username.equals(username, ignoreCase = true)) it.copy(isBanned = true, isOnline = false) else it
        }
    }

    fun unbanPlayer(username: String) {
        _players.value = _players.value.map {
            if (it.username.equals(username, ignoreCase = true)) it.copy(isBanned = false) else it
        }
    }
}
