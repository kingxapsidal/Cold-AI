package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Server profile saved locally for connecting to Pterodactyl and Minecraft
 */
data class ServerProfile(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "ColdMC Server",
    val panelUrl: String = "https://panel.npcraft.bond",
    val apiKey: String = "",
    val panelUser: String = "",
    val serverIdentifier: String = "", // Pterodactyl 8-character ID
    val minecraftHost: String = "panel.npcraft.bond",
    val minecraftPort: Int = 25565,
    val isFastApiGatewayMode: Boolean = false,
    val fastApiBaseUrl: String = "http://192.168.1.10:8000"
)

// Pterodactyl API Models
@JsonClass(generateAdapter = true)
data class PteroListResponse<T>(
    val `object`: String = "list",
    val data: List<PteroDataObject<T>> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroDataObject<T>(
    val `object`: String = "",
    val attributes: T
)

@JsonClass(generateAdapter = true)
data class ServerAttributes(
    val identifier: String = "",
    val uuid: String = "",
    val name: String = "",
    val node: String = "",
    val description: String? = null,
    val limits: ServerLimits = ServerLimits(),
    val status: String? = null,
    @Json(name = "is_suspended") val isSuspended: Boolean = false,
    @Json(name = "is_installing") val isInstalling: Boolean = false
)

@JsonClass(generateAdapter = true)
data class ServerLimits(
    val memory: Long = 0,
    val swap: Long = 0,
    val disk: Long = 0,
    val io: Long = 0,
    val cpu: Long = 0
)

@JsonClass(generateAdapter = true)
data class ResourceStatsResponse(
    val `object`: String = "stats",
    val attributes: ResourceStats = ResourceStats()
)

@JsonClass(generateAdapter = true)
data class ResourceStats(
    @Json(name = "current_state") val currentState: String = "offline", // running, starting, stopping, offline
    @Json(name = "is_suspended") val isSuspended: Boolean = false,
    val resources: ResourceUsage = ResourceUsage()
)

@JsonClass(generateAdapter = true)
data class ResourceUsage(
    @Json(name = "memory_bytes") val memoryBytes: Long = 0,
    @Json(name = "cpu_absolute") val cpuAbsolute: Double = 0.0,
    @Json(name = "disk_bytes") val diskBytes: Long = 0,
    @Json(name = "network_rx_bytes") val networkRxBytes: Long = 0,
    @Json(name = "network_tx_bytes") val networkTxBytes: Long = 0,
    val uptime: Long = 0
)

@JsonClass(generateAdapter = true)
data class PowerSignalRequest(
    val signal: String // "start", "stop", "restart", "kill"
)

@JsonClass(generateAdapter = true)
data class CommandRequest(
    val command: String
)

@JsonClass(generateAdapter = true)
data class FileAttributes(
    val name: String = "",
    val mode: String = "",
    val size: Long = 0,
    @Json(name = "is_file") val isFile: Boolean = true,
    @Json(name = "is_symlink") val isSymlink: Boolean = false,
    val mimetype: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "modified_at") val modifiedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class DeleteFilesRequest(
    val root: String = "/",
    val files: List<String>
)

@JsonClass(generateAdapter = true)
data class PullFileRequest(
    val url: String,
    val directory: String = "/plugins"
)

@JsonClass(generateAdapter = true)
data class BackupAttributes(
    val uuid: String = "",
    val name: String = "",
    val bytes: Long = 0,
    @Json(name = "is_successful") val isSuccessful: Boolean = true,
    @Json(name = "is_locked") val isLocked: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "completed_at") val completedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateBackupRequest(
    val name: String = "ColdMC-AutoBackup",
    @Json(name = "is_locked") val isLocked: Boolean = false
)

// Modrinth API Models
@JsonClass(generateAdapter = true)
data class ModrinthSearchResponse(
    val hits: List<ModrinthHit> = emptyList(),
    val offset: Int = 0,
    val limit: Int = 10,
    @Json(name = "total_hits") val totalHits: Int = 0
)

@JsonClass(generateAdapter = true)
data class ModrinthHit(
    @Json(name = "project_id") val projectId: String = "",
    val slug: String = "",
    val title: String = "",
    val description: String = "",
    val categories: List<String> = emptyList(),
    @Json(name = "project_type") val projectType: String = "plugin",
    val downloads: Long = 0,
    val icon_url: String? = null,
    val versions: List<String> = emptyList(),
    @Json(name = "gallery") val gallery: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ModrinthVersion(
    val id: String = "",
    @Json(name = "project_id") val projectId: String = "",
    val name: String = "",
    @Json(name = "version_number") val versionNumber: String = "",
    @Json(name = "game_versions") val gameVersions: List<String> = emptyList(),
    val loaders: List<String> = emptyList(),
    val files: List<ModrinthFile> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ModrinthFile(
    val url: String = "",
    val filename: String = "",
    val primary: Boolean = true,
    val size: Long = 0
)

// Minecraft Java Server Ping Result
data class MinecraftPingResult(
    val isOnline: Boolean = false,
    val latencyMs: Long = 0,
    val version: String = "Unknown",
    val protocol: Int = 0,
    val playersOnline: Int = 0,
    val playersMax: Int = 0,
    val motdClean: String = "",
    val playerSample: List<String> = emptyList(),
    val error: String? = null
)

// AI Assistant Action & Message
data class AiMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val pendingAction: AiActionProposal? = null
)

enum class MessageSender {
    USER, AI, SYSTEM
}

data class AiActionProposal(
    val id: String = java.util.UUID.randomUUID().toString(),
    val actionType: ActionType,
    val title: String,
    val description: String,
    val payload: String, // e.g. command or filename
    var status: ActionStatus = ActionStatus.PENDING
)

// Pterodactyl Panel Entity for Multi-Panel System
data class PterodactylPanel(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "Main Pterodactyl Panel",
    val url: String = "https://panel.npcraft.bond",
    val apiKey: String = "",
    val username: String = "",
    val passwordMasked: String = "",
    val isConnected: Boolean = true,
    val status: String = "Connected", // Connected, Disconnected, Testing, Error
    val lastTested: Long = System.currentTimeMillis(),
    val serverCount: Int = 1
)

// Managed Minecraft Server Instance
data class ManagedServer(
    val id: String = java.util.UUID.randomUUID().toString(),
    val panelId: String = "",
    val panelName: String = "Main Pterodactyl Panel",
    val identifier: String = "", // 8-char Pterodactyl server ID
    val name: String = "COLDMC Server",
    val customDisplayName: String = "Survival Server",
    val node: String = "Node-Alpha",
    val minecraftHost: String = "panel.npcraft.bond",
    val minecraftPort: Int = 25565,
    val memoryLimitMb: Long = 4096,
    val diskLimitMb: Long = 10240,
    val cpuLimitPercent: Long = 200,
    val status: String = "running"
)

// Discord Bot & Webhook Integration
data class DiscordConfig(
    val webhookUrl: String = "",
    val botToken: String = "",
    val channelId: String = "",
    val notifyOnline: Boolean = true,
    val notifyOffline: Boolean = true,
    val notifyCrash: Boolean = true,
    val notifyBackup: Boolean = true,
    val notifyPlayerJoin: Boolean = false,
    val notifyAntiCheat: Boolean = true
)

// Audit Log / Activity History
data class AuditLogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String = "Operator", // "Operator", "COLDMC AI", "System"
    val action: String = "Start Server",
    val serverName: String = "Survival Server",
    val status: String = "SUCCESS", // "SUCCESS", "FAILED", "PENDING_APPROVAL"
    val details: String = "Dispatched via Pterodactyl Client API"
)

// Dedicated Crash Report Diagnostics
data class CrashReportAnalysis(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: String = "Just now",
    val exceptionType: String = "OutOfMemoryError: Java heap space",
    val culpritModule: String = "JVM Heap Allocation / Heavy World Chunks",
    val summary: String = "The server ran out of allocated RAM while generating new Nether chunks.",
    val suggestedFix: String = "1. Allocate at least 4096MB heap.\n2. Add `-XX:+UseG1GC` flag.\n3. Lower view-distance to 6 in `server.properties`.",
    val severity: String = "CRITICAL",
    val stackTraceSnippet: String = "java.lang.OutOfMemoryError: Java heap space\n\tat net.minecraft.world.level.chunk.LevelChunk.getBlockState(LevelChunk.java:182)\n\tat net.minecraft.server.level.ServerChunkCache.tick(ServerChunkCache.java:412)"
)

// Mod Project Model
data class ModProject(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val slug: String,
    val loader: String, // Fabric, Forge, NeoForge, Quilt
    val description: String,
    val gameVersion: String = "1.21.1",
    val downloads: Long = 0,
    val iconUrl: String? = null,
    val filename: String = "",
    val downloadUrl: String = "",
    val isInstalled: Boolean = false
)

enum class ActionType {
    START_SERVER,
    RESTART_SERVER,
    STOP_SERVER,
    EXECUTE_COMMAND,
    DELETE_FILE,
    INSTALL_PLUGIN,
    INSTALL_MOD,
    CREATE_BACKUP,
    BAN_PLAYER
}

enum class ActionStatus {
    PENDING, CONFIRMED, REJECTED, EXECUTED
}

// Moderation & Player Management
data class PlayerInfo(
    val username: String,
    val uuid: String = "",
    val isOnline: Boolean = false,
    val isOp: Boolean = false,
    val isWhitelisted: Boolean = false,
    val isBanned: Boolean = false,
    val ping: Int = 0
)

data class AntiCheatViolation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val player: String,
    val checkName: String, // "Speed (Type B)", "Reach (3.42 blocks)", "KillAura (Angle 74deg)", "Chat Spam"
    val category: String, // "Combat", "Movement", "Chat", "World"
    val severity: ViolationSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val ping: Int = 45,
    val details: String,
    val status: String = "Flagged" // Flagged, Muted, Banned, Dismissed
)

enum class ViolationSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}

