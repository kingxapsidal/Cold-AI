package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ColdMcTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ColdMcViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ColdMcViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ColdMcTheme(darkTheme = true) {
                MainAppScreen(viewModel)
            }
        }
    }
}

enum class Screen(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    CONSOLE("Console", Icons.Default.Terminal),
    PLUGINS("Plugins", Icons.Default.Extension),
    MODS("Mods", Icons.Default.Build),
    AI_ADMIN("AI Admin", Icons.Default.AutoAwesome),
    SECURITY("Security", Icons.Default.Shield),
    FILES("Files", Icons.Default.Folder),
    BACKUPS("Backups", Icons.Default.Backup),
    PERFORMANCE("Performance", Icons.Default.Speed),
    PANELS("Panels", Icons.Default.CloudQueue),
    SERVERS("Servers", Icons.Default.Layers),
    DISCORD("Discord", Icons.Default.NotificationsActive),
    CRASH_ANALYSIS("Crash Doctor", Icons.Default.BugReport),
    ACTIVITY_HISTORY("History", Icons.Default.HistoryEdu),
    SETTINGS("Settings", Icons.Default.Settings),
    CONNECTION_SETUP("Connection", Icons.Default.VpnKey),
    WELCOME("Welcome", Icons.Default.Info)
}

@Composable
fun MainAppScreen(viewModel: ColdMcViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
    val activeProfile by viewModel.activeProfile.collectAsState()
    val stats by viewModel.resourceStats.collectAsState()
    val snackbarMsg by viewModel.snackbarMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Handle back button when inside sub-screens
    BackHandler(enabled = currentScreen != Screen.DASHBOARD) {
        currentScreen = Screen.DASHBOARD
    }

    LaunchedEffect(snackbarMsg) {
        if (snackbarMsg != null) {
            snackbarHostState.showSnackbar(snackbarMsg!!)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        containerColor = CyberBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (currentScreen != Screen.CONNECTION_SETUP &&
                currentScreen != Screen.CONSOLE &&
                currentScreen != Screen.FILES &&
                currentScreen != Screen.PLUGINS &&
                currentScreen != Screen.MODS &&
                currentScreen != Screen.AI_ADMIN &&
                currentScreen != Screen.SECURITY &&
                currentScreen != Screen.BACKUPS &&
                currentScreen != Screen.PERFORMANCE &&
                currentScreen != Screen.PANELS &&
                currentScreen != Screen.SERVERS &&
                currentScreen != Screen.DISCORD &&
                currentScreen != Screen.CRASH_ANALYSIS &&
                currentScreen != Screen.ACTIVITY_HISTORY &&
                currentScreen != Screen.SETTINGS &&
                currentScreen != Screen.WELCOME
            ) {
                ColdMcTopBar(
                    title = activeProfile?.name ?: "ColdMC Server",
                    subtitle = "${activeProfile?.panelUrl ?: ""} (${activeProfile?.serverIdentifier.takeIf { !it.isNullOrBlank() } ?: "ID: Not Set"})",
                    serverState = stats?.currentState ?: "offline",
                    onConnectionClick = { currentScreen = Screen.CONNECTION_SETUP },
                    onRefreshClick = { viewModel.refreshTelemetry() },
                    onMenuNavigate = { route ->
                        when (route) {
                            "panels" -> currentScreen = Screen.PANELS
                            "servers" -> currentScreen = Screen.SERVERS
                            "performance" -> currentScreen = Screen.PERFORMANCE
                            "mods" -> currentScreen = Screen.MODS
                            "crash_analysis" -> currentScreen = Screen.CRASH_ANALYSIS
                            "discord" -> currentScreen = Screen.DISCORD
                            "activity_history" -> currentScreen = Screen.ACTIVITY_HISTORY
                            "backups" -> currentScreen = Screen.BACKUPS
                            "files" -> currentScreen = Screen.FILES
                            "settings" -> currentScreen = Screen.SETTINGS
                            "welcome" -> currentScreen = Screen.WELCOME
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (currentScreen != Screen.CONNECTION_SETUP && currentScreen != Screen.WELCOME) {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 6.dp
                ) {
                    val bottomNavScreens = listOf(
                        Screen.DASHBOARD,
                        Screen.CONSOLE,
                        Screen.PLUGINS,
                        Screen.AI_ADMIN,
                        Screen.SECURITY
                    )

                    bottomNavScreens.forEach { screen ->
                        val isSelected = currentScreen == screen
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            selected = isSelected,
                            onClick = { currentScreen = screen },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = IceCyan,
                                indicatorColor = IceCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentScreen, label = "screen_fade") { screen ->
                when (screen) {
                    Screen.DASHBOARD -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigate = { route ->
                            when (route) {
                                "console" -> currentScreen = Screen.CONSOLE
                                "files" -> currentScreen = Screen.FILES
                                "plugins" -> currentScreen = Screen.PLUGINS
                                "mods" -> currentScreen = Screen.MODS
                                "ai" -> currentScreen = Screen.AI_ADMIN
                                "security" -> currentScreen = Screen.SECURITY
                                "backups" -> currentScreen = Screen.BACKUPS
                                "connection" -> currentScreen = Screen.CONNECTION_SETUP
                                "panels" -> currentScreen = Screen.PANELS
                                "servers" -> currentScreen = Screen.SERVERS
                                "performance" -> currentScreen = Screen.PERFORMANCE
                                "crash_analysis" -> currentScreen = Screen.CRASH_ANALYSIS
                                "discord" -> currentScreen = Screen.DISCORD
                                "activity_history" -> currentScreen = Screen.ACTIVITY_HISTORY
                                "settings" -> currentScreen = Screen.SETTINGS
                                "welcome" -> currentScreen = Screen.WELCOME
                            }
                        }
                    )
                    Screen.CONSOLE -> ConsoleScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.FILES -> FileManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.PLUGINS -> PluginManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.MODS -> ModManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.AI_ADMIN -> AiAdminScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.SECURITY -> SecurityHubScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.BACKUPS -> BackupsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.PERFORMANCE -> PerformanceScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.PANELS -> PanelManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.SERVERS -> ServerManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.CRASH_ANALYSIS -> CrashAnalysisScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.DISCORD -> DiscordIntegrationScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.ACTIVITY_HISTORY -> ActivityHistoryScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.CONNECTION_SETUP -> ConnectionSetupScreen(
                        viewModel = viewModel,
                        onBackOrDone = { currentScreen = Screen.DASHBOARD }
                    )
                    Screen.WELCOME -> WelcomeSplashScreen(
                        onGetStarted = { currentScreen = Screen.DASHBOARD },
                        onDirectPanelSetup = { currentScreen = Screen.PANELS }
                    )
                }
            }
        }
    }
}

