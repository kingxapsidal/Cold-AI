package com.example

import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class ColdMcLogicTest {

    @Test
    fun testServerProfileDefaults() {
        val profile = ServerProfile()
        assertEquals("ColdMC Server", profile.name)
        assertEquals("https://panel.npcraft.bond", profile.panelUrl)
        assertEquals(25565, profile.minecraftPort)
        assertFalse(profile.isFastApiGatewayMode)
    }

    @Test
    fun testMultiPanelDefaults() {
        val panel = PterodactylPanel(
            name = "Apex Hosting Node",
            url = "https://panel.apexhosting.com",
            apiKey = "ptlc_secret_key"
        )
        assertEquals("Apex Hosting Node", panel.name)
        assertEquals("https://panel.apexhosting.com", panel.url)
        assertEquals("Connected", panel.status)
        assertTrue(panel.isConnected)
    }

    @Test
    fun testManagedServerModel() {
        val server = ManagedServer(
            panelId = "p-1",
            panelName = "NPCraft",
            identifier = "a1b2c3d4",
            name = "Survival Hardcore",
            customDisplayName = "SMP Season 3",
            minecraftHost = "mc.example.com",
            minecraftPort = 25565
        )
        assertEquals("a1b2c3d4", server.identifier)
        assertEquals("SMP Season 3", server.customDisplayName)
        assertEquals("mc.example.com", server.minecraftHost)
    }

    @Test
    fun testAiActionProposalState() {
        val proposal = AiActionProposal(
            actionType = ActionType.RESTART_SERVER,
            title = "Restart Minecraft Server",
            description = "Restart test instance",
            payload = "restart"
        )
        assertEquals(ActionStatus.PENDING, proposal.status)
        proposal.status = ActionStatus.CONFIRMED
        assertEquals(ActionStatus.CONFIRMED, proposal.status)
    }

    @Test
    fun testActionTypeExpansions() {
        val startProposal = AiActionProposal(
            actionType = ActionType.START_SERVER,
            title = "Start Server",
            description = "Start server",
            payload = "start"
        )
        assertEquals(ActionType.START_SERVER, startProposal.actionType)

        val backupProposal = AiActionProposal(
            actionType = ActionType.CREATE_BACKUP,
            title = "Create Snapshot Backup",
            description = "Backup server",
            payload = "backup-01"
        )
        assertEquals(ActionType.CREATE_BACKUP, backupProposal.actionType)
    }

    @Test
    fun testAuditLogCreation() {
        val log = AuditLogEntry(
            actor = "COLDMC AI",
            action = "Restart Server",
            serverName = "Survival Server",
            status = "SUCCESS",
            details = "Signal dispatched via Pterodactyl API"
        )
        assertEquals("COLDMC AI", log.actor)
        assertEquals("SUCCESS", log.status)
    }

    @Test
    fun testDiscordConfigDefaults() {
        val config = DiscordConfig()
        assertTrue(config.notifyOnline)
        assertTrue(config.notifyOffline)
        assertTrue(config.notifyCrash)
        assertTrue(config.notifyBackup)
        assertTrue(config.notifyAntiCheat)
    }
}
