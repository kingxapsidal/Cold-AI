import os
import sys
import json
import sqlite3
import hashlib
import asyncio
from typing import List, Optional
from datetime import datetime
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import httpx

app = FastAPI(title="COLDMC AI Backend Gateway", version="2.4.0")

# Enable CORS for local network (Wi-Fi) and web dashboards
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = os.path.join(os.path.dirname(__file__), "coldmc.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    # Users
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # Panels
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS panels (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            username TEXT,
            api_key_enc TEXT,
            status TEXT DEFAULT 'Connected',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # Servers
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS servers (
            id TEXT PRIMARY KEY,
            panel_id TEXT,
            identifier TEXT NOT NULL,
            name TEXT NOT NULL,
            host TEXT DEFAULT '127.0.0.1',
            port INTEGER DEFAULT 25565,
            status TEXT DEFAULT 'running',
            FOREIGN KEY(panel_id) REFERENCES panels(id)
        )
    """)
    # AI Conversations
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ai_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            sender TEXT,
            content TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # AI Actions
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ai_actions (
            id TEXT PRIMARY KEY,
            action_type TEXT,
            title TEXT,
            status TEXT DEFAULT 'PENDING',
            payload TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # Backups
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS backups (
            id TEXT PRIMARY KEY,
            server_id TEXT,
            name TEXT,
            bytes INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # Discord Settings
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS discord_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            webhook_url TEXT,
            bot_token TEXT,
            channel_id TEXT,
            notify_online INTEGER DEFAULT 1,
            notify_offline INTEGER DEFAULT 1,
            notify_crash INTEGER DEFAULT 1,
            notify_backup INTEGER DEFAULT 1,
            notify_anti_cheat INTEGER DEFAULT 1
        )
    """)
    # Audit Logs
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id TEXT PRIMARY KEY,
            timestamp INTEGER,
            actor TEXT,
            action TEXT,
            server_name TEXT,
            status TEXT,
            details TEXT
        )
    """)
    # Seed default panel & server if none exist
    cursor.execute("SELECT COUNT(*) FROM panels")
    if cursor.fetchone()[0] == 0:
        cursor.execute(
            "INSERT INTO panels (id, name, url, username, api_key_enc, status) VALUES (?, ?, ?, ?, ?, ?)",
            ("p-1", "NPCraft Hosting", "https://panel.npcraft.bond", "admin", "", "Connected")
        )
        cursor.execute(
            "INSERT INTO servers (id, panel_id, identifier, name, host, port, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("s-1", "p-1", "coldmc01", "COLDMC Survival (1.21.1)", "panel.npcraft.bond", 25565, "running")
        )
        cursor.execute(
            "INSERT INTO audit_logs (id, timestamp, actor, action, server_name, status, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("a-1", int(datetime.now().timestamp() * 1000), "System", "Initialized Gateway Database", "Survival Server", "SUCCESS", "Local SQLite schema created")
        )
    conn.commit()
    conn.close()

init_db()

# Models
class PowerRequest(BaseModel):
    signal: str

class CommandRequest(BaseModel):
    command: str

class PanelModel(BaseModel):
    id: Optional[str] = None
    name: str
    url: str
    username: Optional[str] = ""
    apiKey: Optional[str] = ""

class ServerModel(BaseModel):
    id: Optional[str] = None
    panelId: str
    identifier: str
    name: str
    host: Optional[str] = "127.0.0.1"
    port: Optional[int] = 25565

class AiChatRequest(BaseModel):
    message: str
    server_id: Optional[str] = None

class DiscordConfigRequest(BaseModel):
    webhook_url: str
    bot_token: Optional[str] = ""
    channel_id: Optional[str] = ""

# API Endpoints
@app.get("/api/health")
async def health_check():
    return {
        "status": "online",
        "service": "COLDMC AI Gateway",
        "db": "SQLite connected",
        "version": "2.4.0",
        "timestamp": datetime.utcnow().isoformat()
    }

# Panels Endpoints
@app.get("/api/panels")
async def get_panels():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM panels")
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

@app.post("/api/panels")
async def create_panel(panel: PanelModel):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    panel_id = panel.id or f"p-{int(datetime.now().timestamp())}"
    cursor.execute(
        "INSERT OR REPLACE INTO panels (id, name, url, username, api_key_enc, status) VALUES (?, ?, ?, ?, ?, ?)",
        (panel_id, panel.name, panel.url.rstrip("/"), panel.username, panel.apiKey, "Connected")
    )
    conn.commit()
    conn.close()
    return {"status": "success", "id": panel_id}

@app.delete("/api/panels/{panel_id}")
async def delete_panel(panel_id: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM panels WHERE id = ?", (panel_id,))
    cursor.execute("DELETE FROM servers WHERE panel_id = ?", (panel_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}

# Servers Endpoints
@app.get("/api/servers")
async def get_servers():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM servers")
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

@app.post("/api/servers")
async def create_server(srv: ServerModel):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    srv_id = srv.id or f"s-{int(datetime.now().timestamp())}"
    cursor.execute(
        "INSERT OR REPLACE INTO servers (id, panel_id, identifier, name, host, port, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (srv_id, srv.panelId, srv.identifier, srv.name, srv.host, srv.port, "running")
    )
    conn.commit()
    conn.close()
    return {"status": "success", "id": srv_id}

@app.delete("/api/servers/{server_id}")
async def delete_server(server_id: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM servers WHERE id = ?", (server_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}

@app.get("/api/servers/{server_id}/stats")
async def get_server_stats(server_id: str):
    return {
        "current_state": "running",
        "is_suspended": False,
        "resources": {
            "memory_bytes": 2147483648,
            "cpu_absolute": 18.5,
            "disk_bytes": 4500000000,
            "network_rx_bytes": 845000,
            "network_tx_bytes": 1200000,
            "uptime": 142000
        }
    }

@app.post("/api/servers/{server_id}/power")
async def send_power(server_id: str, req: PowerRequest):
    return {"status": "success", "signal": req.signal, "server_id": server_id}

@app.post("/api/servers/{server_id}/command")
async def send_command(server_id: str, req: CommandRequest):
    return {"status": "dispatched", "command": req.command, "server_id": server_id}

# AI Assistant with English & Roman Urdu understanding
@app.post("/api/ai/chat")
async def ai_chat(req: AiChatRequest):
    query = req.message.lower().strip()
    
    # 1. Start Server
    if "start" in query or "chalu" in query:
        return {
            "reply": "Main aapka Minecraft server start karne ke liye tayyar hoon. Power signal send karne ke liye confirm karein.",
            "action": {"type": "START_SERVER", "title": "Start Server", "payload": "start"}
        }
    # 2. Restart Server
    elif "restart" in query or "dobara" in query:
        return {
            "reply": "Server restart karne se tamam active players disconnect ho jayenge aur plugins reload honge. Would you like me to restart?",
            "action": {"type": "RESTART_SERVER", "title": "Restart Server", "payload": "restart"}
        }
    # 3. Stop Server
    elif "stop" in query or "band" in query:
        return {
            "reply": "Warning: Stopping the server will disconnect all online players and safely save world chunks.",
            "action": {"type": "STOP_SERVER", "title": "Stop Server", "payload": "stop"}
        }
    # 4. RAM / Resource Check
    elif "ram" in query or "memory" in query or "cpu" in query:
        return {
            "reply": "📊 Server Telemetry: RAM currently at 2048 MB / 4096 MB (50%). CPU load is 18.5%. Everything is operating within safe limits.",
            "action": None
        }
    # 5. Online Players
    elif "player" in query or "online" in query:
        return {
            "reply": "👥 Online Players: 12 / 60 players connected. Ping is 34 ms.",
            "action": None
        }
    # 6. Crash Diagnostics
    elif "crash" in query or "error" in query or "kyun" in query:
        return {
            "reply": "🔍 Crash Analysis: Check `/crash-reports/` via File Manager. Most common cause is OutOfMemoryError when heap is below 4GB or Java 21 bytecode requirement is missing.",
            "action": None
        }
    # 7. Backup
    elif "backup" in query:
        return {
            "reply": "I can create an on-demand snapshot backup on Pterodactyl. Please confirm below.",
            "action": {"type": "CREATE_BACKUP", "title": "Create Snapshot Backup", "payload": f"ColdMC-Backup-{int(datetime.now().timestamp())}"}
        }
    else:
        return {
            "reply": f"COLDMC AI received: '{req.message}'. Checking server telemetry and ready to assist in English or Roman Urdu.",
            "action": None
        }

# Discord Webhook Test & Config
@app.post("/api/discord/test")
async def test_discord(req: DiscordConfigRequest):
    if not req.webhook_url:
        raise HTTPException(status_code=400, detail="Webhook URL is empty")
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.post(req.webhook_url, json={
                "username": "COLDMC AI Guardian",
                "content": "❄️ **COLDMC AI** Gateway connection successfully verified from Windows PC / Local Network!"
            })
            return {"status": "dispatched", "code": resp.status_code}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Audit Logs
@app.get("/api/audit-logs")
async def get_audit_logs():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 50")
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

@app.websocket("/ws/console/{server_id}")
async def websocket_console(websocket: WebSocket, server_id: str):
    await websocket.accept()
    try:
        await websocket.send_text(f"[COLDMC WS]: Connected to live console stream for server {server_id}")
        count = 1
        while True:
            await asyncio.sleep(4)
            await websocket.send_text(f"[TICK {count}]: TPS: 20.0, Heap: 2.1GB / 4.0GB, Players: 12")
            count += 1
    except WebSocketDisconnect:
        pass

# Mount static web dashboard
static_path = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_path):
    app.mount("/static", StaticFiles(directory=static_path), name="static")

@app.get("/")
async def serve_dashboard():
    index_file = os.path.join(static_path, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "COLDMC AI Gateway API is running. Open /docs for Swagger API documentation."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
