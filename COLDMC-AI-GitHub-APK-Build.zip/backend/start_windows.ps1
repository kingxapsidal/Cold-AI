# COLDMC AI — PowerShell Windows Gateway Launcher
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "       COLDMC AI - MINECRAFT JAVA SERVER GATEWAY        " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

# Check Python
$pythonExists = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonExists) {
    Write-Host "[ERROR] Python 3.10+ was not found on your system." -ForegroundColor Red
    Write-Host "Please install from https://www.python.org/ or the Microsoft Store."
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Installing requirements..." -ForegroundColor Yellow
pip install -r requirements.txt

# Detect local IP
$localIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch "Loopback" -and $_.IPAddress -like "192.168.*" -or $_.IPAddress -like "10.*" } | Select-Object -First 1).IPAddress

Write-Host ""
Write-Host "COLDMC AI Gateway running:" -ForegroundColor Green
Write-Host "• Local PC Browser:   http://localhost:8000" -ForegroundColor White
if ($localIP) {
    Write-Host "• Android via Wi-Fi:  http://$($localIP):8000" -ForegroundColor Green
} else {
    Write-Host "• Android via Wi-Fi:  http://<YOUR_PC_IP>:8000 (check ipconfig)" -ForegroundColor Yellow
}
Write-Host ""

uvicorn main:app --host 0.0.0.0 --port 8000 --reload
