# COLDMC AI — Python FastAPI Backend Gateway & Windows Support

The companion backend gateway for **COLDMC AI**. It runs on your Windows PC (or Linux server) on your local Wi-Fi network and interfaces with unlimited Pterodactyl panels, Minecraft servers, Discord notifications, and AI operators.

---

## ⚡ 1-Click Launch on Windows PC

Double-click `start_windows.bat` or run PowerShell:
```powershell
.\start_windows.ps1
```
This automatically verifies dependencies and launches the gateway on `http://0.0.0.0:8000`.

---

## 💻 Manual Setup & Execution

1. **Install Python 3.10+** (ensure "Add Python to PATH" is checked during install).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the gateway:
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```
4. Access the **PC Web Dashboard**:
   [http://localhost:8000](http://localhost:8000)
5. Access the interactive **Swagger REST API Docs**:
   [http://localhost:8000/docs](http://localhost:8000/docs)

---

## 📶 Connecting Android Phone over Local Wi-Fi

1. **Find your PC's Wi-Fi IP address**:
   - Open Command Prompt on Windows and run `ipconfig`.
   - Look for `IPv4 Address` under your Wi-Fi or Ethernet adapter (e.g., `192.168.1.10`).
2. **Configure COLDMC AI on Android**:
   - Open **COLDMC AI** on your phone (connected to the same Wi-Fi).
   - Tap the top-right menu -> **Settings & Wi-Fi Gateway**.
   - Enable **Use Local PC Gateway** and enter:
     `http://192.168.1.10:8000`
   - Tap **Test & Save Wi-Fi Gateway**.
3. **Windows Firewall Tip**:
   - If Android cannot reach your PC, allow Python/Port 8000 through Windows Defender Firewall:
     `netsh advfirewall firewall add rule name="COLDMC AI Gateway" dir=in action=allow protocol=TCP localport=8000`

---

## 🗄️ SQLite Database Architecture (`coldmc.db`)

The gateway manages persistent storage in `backend/coldmc.db` with the following tables:
- `users`: Operator accounts with bcrypt/SHA256 password hashes.
- `panels`: Unlimited Pterodactyl panels with isolated credentials.
- `servers`: Minecraft server instances linked to their parent panel.
- `ai_conversations`: Chat history with timestamped operator and AI dialog.
- `ai_actions`: Controlled tool execution log (Pending, Confirmed, Executed).
- `backups`: Server snapshot history.
- `discord_settings`: Webhook URL, bot token, and notification toggle states.
- `audit_logs`: Immutable security ledger for power dispatches, file edits, and moderation.

---

## 🌐 Remote Access Outside Local Wi-Fi

If you want to access your PC gateway outside your home Wi-Fi:
- Use **Tailscale** or **ZeroTier** (free, secure mesh VPN).
- Or use **Cloudflare Tunnel** (`cloudflared tunnel --url http://localhost:8000`).
