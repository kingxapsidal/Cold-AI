@echo off
title COLDMC AI — Windows Gateway & Local Web Dashboard
color 0B

echo ========================================================
echo         COLDMC AI - MINECRAFT JAVA SERVER GATEWAY
echo ========================================================
echo.
echo Checking Python environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    pause
    exit /b 1
)

echo Installing / Verifying dependencies from requirements.txt...
pip install -r requirements.txt

echo.
echo ========================================================
echo Starting COLDMC AI Gateway on http://0.0.0.0:8000
echo Access on this PC: http://localhost:8000
echo Access on Android via Wi-Fi: http://<YOUR_PC_IP>:8000
echo (Find your PC IP by running 'ipconfig' in command prompt)
echo ========================================================
echo.

uvicorn main:app --host 0.0.0.0 --port 8000 --reload
pause
